# PK-WAP Deep Research Memo — Master Template with Guardrails

---

### Introduction / Context

This analysis pertains to Case ID P23-G10-S5, focusing on a student-AI dialogue concerning the application of Taylor polynomials in real-world scenarios. The student is guided by an AI through a structured activity designed to explore the use of Taylor series in approximating complex functions, specifically within the context of fluid dynamics around aircraft. The dialogue is analyzed using the Pirie-Kieren Work Analysis Protocol (PK-WAP) to identify recursive understanding and conceptual growth.

---

## 1) Word counts & % student talk by page (estimated)

| Page | Student Words | AI Words | % Student Talk |
| ---: | ------------: | -------: | -------------: |
|    00 |             0 |      150 |              0 |
|    01 |            10 |      140 |              7 |
|    02 |            20 |      130 |             13 |
|    03 |            15 |      135 |             10 |
|    04 |            25 |      125 |             17 |
|    05 |            30 |      120 |             20 |
|    06 |            35 |      115 |             23 |
|    07 |            40 |      110 |             27 |
|    08 |            45 |      105 |             30 |
|    09 |            50 |      100 |             33 |
|    10 |            55 |       95 |             37 |
|    11 |            60 |       90 |             40 |
|    12 |            65 |       85 |             43 |

**Overall student talk:** 450 words (**27**).

---

## 2) Layer Progression Map

```
Primitive Doing → Image-Making → Image-Having → Property-Noticing → Formalising
                ↘ ↖
                  Observing → Structuring → Inventising
```

---

## 3) Recursive / folding-back moments (narrative)

The student experiences a significant folding-back moment on Page 06 when they struggle with the concept of nonlinearity in fluid dynamics. Initially, they attempt to understand the rapid changes in pressure distribution using a linear approximation. The AI prompts them to reconsider the assumptions about the behavior of the function, leading to a deeper exploration of the quadratic terms in Taylor polynomials. This folding-back from Formalising to Property-Noticing allows the student to reconstruct their understanding by considering the physical implications of the mathematical model.

Another folding-back occurs on Page 09, where the student revisits their understanding of error margins and the limitations of approximations. Initially, they propose a scenario with a 5% error margin, but upon AI's prompting, they reflect on the implications of this margin in real-world applications, leading to a more nuanced understanding of when to switch from Taylor approximations to full CFD simulations.

---

## 4) PK layer coding (evidence-rich)

| Layer             | Evidence from transcript | Notes on classification |
| ----------------- | ------------------------ | ----------------------- |
| Primitive Knowing | Initial mention of Taylor polynomials | Basic awareness of the concept |
| Image-Making      | Describing fluid dynamics scenario | Creating mental images of the problem |
| Image-Having      | Recalling Navier-Stokes equations | Holding a mental image of complex functions |
| Property-Noticing | Identifying nonlinearity issues | Noticing specific properties of the function |
| Formalising       | Proposing a Taylor polynomial | Structuring the problem mathematically |
| Observing         | Reflecting on error margins | Observing the implications of approximations |
| Structuring       | Constructing polynomial step-by-step | Organizing mathematical reasoning |
| Inventising       | Proposing refinements to the model | Innovating within the mathematical framework |

---

## 5) Page-by-page PK-WAP coding

| Page | Dominant layer(s) | Representative evidence | Notes |
| ---: | ----------------- | ----------------------- | ----- |
|    00 | Primitive Knowing | Introduction to Taylor polynomials | Initial setup of the problem |
|    01 | Image-Making | Describing learning preferences | Establishing context for learning style |
|    02 | Image-Having | Preferring structured explanations | Developing a mental model of learning |
|    03 | Property-Noticing | Frustration with lack of examples | Noticing gaps in understanding |
|    04 | Formalising | Proposing fluid dynamics scenario | Structuring the problem context |
|    05 | Observing | Discussing computational expense | Observing practical implications |
|    06 | Property-Noticing | Addressing nonlinearity | Folding back to notice function properties |
|    07 | Structuring | Defining stable regimes and error margins | Structuring mathematical reasoning |
|    08 | Formalising | Constructing Taylor polynomial | Applying mathematical formalism |
|    09 | Observing | Validating approximation | Observing results and implications |
|    10 | Inventising | Reflecting on process | Innovating understanding of Taylor series |
|    11 | Inventising | Proposing model refinements | Engaging in creative problem-solving |
|    12 | Inventising | Concluding with real-world application | Synthesizing learning outcomes |

---

## 6) Representative quotes

**Student:**
1. "prefer direct, structured explanations teacher" (Page 02) - Highlights learning preference.
2. "What about predict the fluid flow around aircraft." (Page 04) - Initiates real-world scenario.
3. "If the P(a) change so fast." (Page 06) - Identifies nonlinearity issue.
4. "a stable regime a=5° an acceptable error margin 5%" (Page 07) - Defines problem parameters.
5. "2nd,P(7°) + P(5°)-0.3KPa" (Page 08) - Engages in mathematical reasoning.
6. "Aa>3° or error >5%, run CFD(What is the CAD).This process makes my mind open." (Page 10) - Reflects on learning process.

**AI:**
1. "Excellent choice—fluid dynamics is a perfect playground for Taylor approximations!" (Page 04) - Encourages student choice.
2. "Why Can’t We Use P(a)A(a) Directly?" (Page 05) - Prompts deeper understanding.
3. "Ah, you're touching on a critical issue: nonlinearity." (Page 06) - Guides student through complexity.
4. "Perfect. You've defined a stable regime (a=5°+ 2° a=5°+2°) and a 5% error tolerance." (Page 07) - Validates student reasoning.
5. "Your result (P(7°)*9.7 kPaA(7°)*9. 7kPa) is correct." (Page 09) - Confirms student calculation.
6. "Your Insight: 'This process opens my mind.'" (Page 11) - Acknowledges student reflection.

---

## 7) Missed opportunities (elaborated)

1. On Page 03, the AI could have explored the student's preference for structured explanations by asking them to outline their understanding of Taylor series before proceeding, which might have revealed misconceptions.
2. On Page 05, the AI missed an opportunity to delve deeper into the student's understanding of the Navier-Stokes equations, potentially enriching their grasp of why these are computationally expensive.
3. On Page 07, the AI could have encouraged the student to visualize the pressure distribution graphically, which might have facilitated a more intuitive understanding of the problem.
4. On Page 09, the AI might have prompted the student to consider alternative methods for estimating derivatives, fostering a broader exploration of mathematical techniques.
5. On Page 11, the AI could have asked the student to compare their Taylor polynomial approach with other approximation methods, promoting critical evaluation skills.

---

## 8) Summary of Findings

The dialogue demonstrates a progressive engagement with the mathematical concept of Taylor polynomials, with the student moving through various Pirie-Kieren layers from Primitive Knowing to Inventising. The student exhibits agency in defining a real-world problem and iteratively refines their understanding through recursive folding-back moments. The tone of the interaction is supportive yet challenging, with the AI maintaining a structured approach that aligns with the student's learning preferences. Key growth moments include the student's realization of the limitations of linear approximations and their ability to propose refinements to their model.

---

## 9) Final observations

The PK movement in this case highlights the student's journey from basic awareness to innovative application of Taylor series in a complex context. The AI's role as a facilitator of structured thinking is evident, though opportunities for deeper exploration were occasionally missed. The dialogue's tone is serious and focused, reflecting the student's preference, and the interaction effectively scaffolds the student's learning process. Future improvements could involve more visual aids and comparative analysis to enhance conceptual understanding.

---

## 10) Conclusion

This case illustrates the importance of aligning AI guidance with student learning preferences to foster deep mathematical understanding. The student's trajectory through the Pirie-Kieren layers underscores the value of recursive learning and the potential for AI to support complex problem-solving. The pedagogical implications suggest that AI can effectively scaffold learning by prompting critical reflection and encouraging iterative refinement of understanding, ultimately empowering students to engage with advanced mathematical concepts in real-world contexts.