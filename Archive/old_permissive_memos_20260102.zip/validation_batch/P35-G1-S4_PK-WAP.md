# PK-WAP Deep Research Memo — Master Template with Guardrails

---

### Introduction / Context

This analysis pertains to transcript P35-G1-S4, which involves a student engaging with an AI tutor to explore the concept of Taylor series and their application in approximating complex functions. The dialogue is structured around a guided activity where the student is prompted to consider real-world scenarios where Taylor approximations are useful. Unlabeled student turns that answer AI prompts are treated as student turns.

---

## 1) Word counts & % student talk by page (estimated)

| Page | Student Words | AI Words | % Student Talk |
| ---: | ------------: | -------: | -------------: |
|    00 |             0 |      152 |              0 |
|    01 |            12 |      234 |              5 |
|    02 |            10 |      202 |              5 |
|    03 |            46 |      210 |             18 |
|    04 |            30 |      220 |             12 |
|    05 |            18 |      230 |              7 |
|    06 |            20 |      240 |              8 |
|    07 |           150 |      250 |             38 |
|    08 |            60 |      180 |             25 |

**Overall student talk:** 346 words (**14%**).

---

## 2) Layer Progression Map

```
Primitive Knowing → Image-Making → Image-Having → Property-Noticing → Formalising
                      ↘︎
```

---

## 3) Recursive / folding-back moments (narrative)

A significant folding-back moment occurs on Page 07 when the student revisits their understanding of Taylor series limitations. Initially, the student constructs a quadratic approximation for a function, but upon realizing the approximation's failure at \( t = 2 \), they fold back to reconsider the role of higher-order terms and the concept of radius of convergence. This reflection allows the student to reconstruct their understanding by acknowledging the local nature of Taylor approximations and the impact of neglected terms.

---

## 4) PK layer coding (evidence-rich)

| Layer             | Evidence from transcript | Notes on classification |
| ----------------- | ------------------------ | ----------------------- |
| Primitive Knowing | Basic understanding of functions and polynomials | Initial engagement with the concept |
| Image-Making      | "Measure the number of bacteria reproducing in an area." | Generating examples of real-world problems |
| Image-Having      | "The first three terms of the Taylor series expansion..." | Recalling and applying known series expansions |
| Property-Noticing | "The function \( e^n \) has a very fast growth rate." | Noticing properties of exponential functions |
| Formalising       | "The final quadratic approximation of \( f(t) \) is 1 + 0.3t - 0.955t^2." | Constructing a formal approximation |
| Observing         | No evidence observed | No metacognitive reflection on the system as a whole |
| Structuring       | No evidence observed | No evidence of connecting multiple observations into a theory |
| Inventising       | No evidence observed | No new mathematical questions or extensions posed |

---

## 5) Page-by-page PK-WAP coding

| Page | Dominant layer(s) | Representative evidence | Notes |
| ---: | ----------------- | ----------------------- | ----- |
|    00 | Primitive Knowing | Initial engagement with the concept | Introduction to the activity |
|    01 | Image-Making      | "Measure the number of bacteria reproducing in an area." | Generating examples |
|    02 | Image-Having      | "The first three terms of the Taylor series expansion..." | Recalling known expansions |
|    03 | Property-Noticing | "The function \( e^n \) has a very fast growth rate." | Noticing properties |
|    04 | Formalising       | "The final quadratic approximation of \( f(t) \) is 1 + 0.3t - 0.955t^2." | Constructing formal approximations |
|    05 | Formalising       | Continued work on approximation | Further formalisation |
|    06 | Formalising       | Testing accuracy of approximation | Application of formal concepts |
|    07 | Property-Noticing | "The Taylor polynomial is an approximation..." | Reflecting on limitations |
|    08 | Property-Noticing | "For the approximation of the function..." | Understanding convergence |

---

## 6) Representative quotes

**Student:**

1. "Measure the number of bacteria reproducing in an area." (Page 01)
2. "The first three terms of the Taylor series expansion..." (Page 02)
3. "The function \( e^n \) has a very fast growth rate." (Page 03)
4. "The final quadratic approximation of \( f(t) \) is 1 + 0.3t - 0.955t^2." (Page 04)
5. "The Taylor polynomial is an approximation..." (Page 07)
6. "For the approximation of the function..." (Page 08)

**AI:**

1. "Think of a situation where predicting behavior *near a known point* matters more than perfect accuracy." (Page 01)
2. "Why is this function problematic for quick predictions?" (Page 03)
3. "Let’s approximate \( f(t) \) near \( t = 0 \)..." (Page 04)
4. "Compare your approximation to the exact \( f(0.1) \)." (Page 06)
5. "Why does the Taylor polynomial fail spectacularly at \( t = 2 \)?" (Page 07)
6. "How did this process change your understanding of Taylor series?" (Page 08)

---

## 7) Missed opportunities (elaborated)

1. **Deeper Exploration of Radius of Convergence:** The AI could have prompted the student to explore the concept of radius of convergence more deeply, perhaps by providing visual aids or simulations to illustrate the concept dynamically.
   
2. **Connecting to Real-World Applications:** While the student provided a real-world scenario, the AI could have encouraged further exploration of how Taylor approximations are used in various fields, enhancing the student's appreciation of the concept's utility.

3. **Encouraging Metacognitive Reflection:** The AI missed opportunities to prompt the student to reflect on their learning process, which could have fostered deeper metacognitive awareness and understanding.

4. **Exploring Higher-Order Terms:** The AI could have guided the student to explore the impact of higher-order terms in more detail, perhaps by calculating additional terms and observing their effects on the approximation.

5. **Facilitating Peer Discussion:** Encouraging the student to discuss their findings with peers or simulate a peer review process could have deepened their understanding and provided diverse perspectives.

---

## 8) Summary of Findings

The dialogue between the student and AI tutor demonstrates a progression through several layers of the Pirie-Kieren framework, primarily reaching up to Formalising. The student begins with basic knowledge and gradually constructs a formal understanding of Taylor series approximations. The AI's structured guidance and use of real-world scenarios help the student engage with the material, though opportunities for deeper exploration and metacognitive reflection were missed. The tone is supportive and encouraging, with the AI adapting its style to the student's preferences.

---

## 9) Final observations

The student's journey through the PK layers highlights the importance of structured guidance in facilitating mathematical understanding. While the AI effectively supports the student's progression to Formalising, incorporating more opportunities for metacognitive reflection and real-world application could enhance learning outcomes. The use of playful language and analogies helps maintain engagement, though balancing this with deeper exploration of mathematical concepts could further enrich the learning experience.

---

## 10) Conclusion

This case illustrates the student's journey through the Pirie-Kieren layers, primarily reaching Formalising, as they engage with Taylor series approximations. The AI's structured approach supports the student's conceptual growth, though additional opportunities for reflection and application could deepen understanding. This analysis underscores the importance of adaptive teaching strategies in fostering mathematical cognition and highlights areas for potential improvement in AI tutoring systems.