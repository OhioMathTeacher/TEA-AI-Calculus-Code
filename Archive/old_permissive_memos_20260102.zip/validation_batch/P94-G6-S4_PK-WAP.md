# PK-WAP Deep Research Memo — Master Template with Guardrails

---

### Introduction / Context

This analysis pertains to transcript P94-G6-S4, which involves a student engaging with an AI tutor in a complex mathematical scenario centered on Taylor polynomials and their application in approximating functions where exact solutions are impractical. The dialogue is structured in a step-by-step format, with the AI providing prompts and feedback as the student works through the mathematical tasks. Unlabeled student turns that respond to AI prompts are treated as student turns.

---

## 1) Word counts & % student talk by page (estimated)

| Page | Student Words | AI Words | % Student Talk |
| ---: | ------------: | -------: | -------------: |
|    0 |            18 |      123 |             13 |
|    1 |           187 |      132 |             59 |
|    2 |           134 |      160 |             46 |
|    3 |           152 |      112 |             58 |
|    4 |           181 |      145 |             56 |
|    5 |           173 |      138 |             56 |
|    6 |           160 |      142 |             53 |
|    7 |           192 |      130 |             60 |
|    8 |           204 |      145 |             58 |
|    9 |           178 |      138 |             56 |
|   10 |            34 |       92 |             27 |

**Overall student talk:** 1,613 words (**53**).

---

## 2) Layer Progression Map

```
Primitive Knowing → Image-Making → Image-Having → Property-Noticing → Formalising
                         ↘
                          ↘
                           ↘
```

---

## 3) Recursive / folding-back moments (narrative)

A notable folding-back moment occurs on Page 03, where the student initially constructs a Taylor expansion for the electron’s position function but is prompted by the AI to reconsider the assumption of smooth differentiability. This requires the student to revisit their understanding of the Taylor series and incorporate additional terms to address time-dependence and cross-terms, thus reconstructing their approach to better align with the physical realities of quantum systems.

Another folding-back instance is observed on Page 06, where the student must refine their error term calculation after realizing the limitations of their initial assumptions regarding the smoothness of wavefunctions. This reflection leads to a deeper understanding of the conditions under which their approximation holds.

---

## 4) PK layer coding (evidence-rich)

| Layer             | Evidence from transcript                                                                 | Notes on classification                                      |
| ----------------- | ---------------------------------------------------------------------------------------- | ------------------------------------------------------------ |
| Primitive Knowing | Initial recognition of Taylor polynomials as a mathematical tool.                        | Basic awareness of the concept without detailed understanding.|
| Image-Making      | Attempting to construct a Taylor expansion for a specific function.                      | Engaging with the task through concrete examples.            |
| Image-Having      | Describing the physical meaning of each term in the Taylor series.                       | Demonstrates a mental image of the mathematical process.     |
| Property-Noticing | Identifying the limitations of the Taylor series in quantum contexts.                    | Recognizing specific properties and constraints.             |
| Formalising       | Deriving the Taylor series from the definition and incorporating error terms.            | Abstracting the process into a formal mathematical procedure.|
| Observing         | No evidence observed.                                                                    | No metacognitive reflection on the system as a whole.        |
| Structuring       | No evidence observed.                                                                    | No synthesis of multiple mathematical ideas into a theory.   |
| Inventising       | No evidence observed.                                                                    | No novel mathematical questions or extensions posed.         |

---

## 5) Page-by-page PK-WAP coding

| Page | Dominant layer(s) | Representative evidence                                                                 | Notes |
| ---: | ----------------- | --------------------------------------------------------------------------------------- | ----- |
|    0 | Primitive Knowing | Recognizing the need for Taylor polynomials in approximating complex functions.         | Basic understanding of the context. |
|    1 | Image-Making      | Constructing the Taylor series from the definition.                                     | Engaging with the task concretely.  |
|    2 | Image-Having      | Describing the physical meaning of Taylor series terms.                                 | Developing a mental image.          |
|    3 | Property-Noticing | Identifying the assumption of smooth differentiability as a limitation.                 | Recognizing constraints.            |
|    4 | Formalising       | Incorporating additional terms for time-dependence and cross-terms.                     | Abstracting the process.            |
|    5 | Formalising       | Refining the error term calculation.                                                    | Further abstraction.                |
|    6 | Property-Noticing | Acknowledging the limitations of the approximation in dynamic systems.                  | Recognizing specific properties.    |
|    7 | Image-Having      | Discussing scenarios where the approximation might hold or fail.                        | Developing a mental image.          |
|    8 | Image-Having      | Justifying the approximation’s validity in specific cases.                              | Further mental image development.   |
|    9 | Property-Noticing | Identifying the impact of strong perturbations on the approximation.                    | Recognizing constraints.            |
|   10 | Image-Making      | Reflecting on the exercise and its implications for tractability in physics.            | Concrete engagement with reflection.|

---

## 6) Representative quotes

**Student:**
1. "It is impossible to accurately calculate the specific motion trajectory of the extranuclear electrons in the electron cloud." (Page 00)
2. "Heisenberg's uncertainty principle states that we cannot simultaneously determine the position and momentum of an electron with arbitrary precision." (Page 01)
3. "Let's perform a Taylor expansion of the electron’s position function U(r, 0, y, t) with respect to the variable r." (Page 02)
4. "The error term (Lagrange-type remainder) of the Taylor expansion is..." (Page 03)
5. "For Rydberg atoms (n = 50), their electron clouds are relatively diffuse." (Page 08)
6. "Attosecond laser pulses have extremely high intensity and will cause a strong perturbation to the atom." (Page 09)

**AI:**
1. "Taylor polynomials are not academic toys. They were born of necessity—Newton used them to approximate orbital paths when exact functions were intolerable." (Page 00)
2. "State precisely why this function cannot be used directly for practical prediction." (Page 01)
3. "Your approximation assumes smooth differentiability. Quantum wavefunctions are notoriously... fractious." (Page 02)
4. "Your expansion of W(r,8,q,t) in r alone is insufficient. Electrons do not politely wait for static snapshots." (Page 03)
5. "Your cutoff at |r-ro| > 0.84a0 is mathematically sound but physically myopic." (Page 06)
6. "Your At < 4.84x10^(-18)s is a fantasy. Real systems are perturbed." (Page 07)

---

## 7) Missed opportunities (elaborated)

1. **Deeper Exploration of Quantum Constraints:** The AI could have prompted the student to explore the implications of Heisenberg's uncertainty principle more deeply, potentially leading to a richer understanding of its impact on approximation methods.
   
2. **Encouraging Metacognitive Reflection:** The AI missed opportunities to encourage the student to reflect on their overall approach and the interconnectedness of the mathematical concepts, which could have facilitated Observing-level insights.

3. **Linking to Real-World Applications:** The AI could have guided the student to consider more real-world scenarios where Taylor series are applied, enhancing the relevance and applicability of the mathematical concepts.

4. **Exploring Alternative Methods:** The AI could have introduced alternative approximation methods, such as numerical simulations, to broaden the student's understanding of the tools available for tackling complex problems.

5. **Addressing Relativistic Effects:** The AI could have prompted the student to consider the impact of relativistic effects, such as spin-orbit coupling, which would have added depth to the analysis of the approximation's limitations.

---

## 8) Summary of Findings

The dialogue between the student and AI demonstrates a moderate level of engagement, with the student progressing through several PK layers, primarily reaching Property-Noticing and Formalising. The tone is rigorous, with the AI adopting a demanding yet supportive role, pushing the student to refine their understanding and approach. Key growth moments include the student's recognition of the limitations of their initial assumptions and their subsequent adjustments to the Taylor series expansion.

The student's agency is evident in their willingness to revise their work in response to AI prompts, although opportunities for deeper metacognitive reflection and exploration of alternative methods were missed. Overall, the dialogue reflects a structured learning process with clear evidence of conceptual growth, albeit within the constraints of the task.

---

## 9) Final observations

The PK movement in this transcript is characterized by a progression from Primitive Knowing to Formalising, with significant folding-back moments that facilitate deeper understanding. The student's agency is supported by the AI's structured prompts, although the dialogue could benefit from more opportunities for metacognitive reflection and exploration of alternative approaches. The tone is rigorous, with the AI maintaining a high standard of precision and accuracy. Future improvements could include encouraging the student to engage in more holistic reflection and consider a wider range of mathematical tools.

---

## 10) Conclusion

This case highlights the importance of structured guidance in facilitating conceptual growth within the Pirie-Kieren framework. The student's trajectory from Primitive Knowing to Formalising demonstrates the potential for deepening understanding through iterative refinement and feedback. However, the absence of Observing, Structuring, and Inventising layers suggests that further opportunities for metacognitive reflection and exploration of alternative methods could enhance learning outcomes. This analysis underscores the value of rigorous, yet flexible, educational dialogues in supporting mathematical cognition.