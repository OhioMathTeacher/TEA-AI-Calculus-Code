# PK-WAP Deep Research Memo — Master Template with Guardrails

---

### Introduction / Context

This memo analyzes the student-AI dialogue transcript P126-GX-S6 using the Pirie-Kieren Work Analysis Protocol (PK-WAP). The scenario involves a student engaging with an AI to explore Taylor polynomial approximations in real-world contexts, specifically in celestial mechanics. The AI's role is to guide the student through problem-solving steps without providing direct answers, fostering a deeper understanding of the mathematical concepts involved.

---

## 1) Word counts & % student talk by page (estimated)

| Page | Student Words | AI Words | % Student Talk |
| ---: | ------------: | -------: | -------------: |
|    00 |            10 |       90 |             10 |
|    01 |            10 |      110 |              8 |
|    02 |             5 |       95 |              5 |
|    03 |             0 |      120 |              0 |
|    04 |            10 |      110 |              8 |
|    05 |            15 |      105 |             13 |
|    06 |            10 |      110 |              8 |
|    07 |            10 |      110 |              8 |
|    08 |            10 |      110 |              8 |
|    09 |            10 |      110 |              8 |
|    10 |            10 |      110 |              8 |
|    11 |            10 |      110 |              8 |
|    12 |            10 |      110 |              8 |
|    13 |            10 |      110 |              8 |
|    14 |             5 |       95 |              5 |

**Overall student talk:** 135 words (**8**).

---

## 2) Layer Progression Map

```
Primitive Doing → Image-Making → Image-Having → Property-Noticing → Formalising
    ↑
    | (Page 05)
    |
    └─── Folding-back
```

---

## 3) Recursive / folding-back moments (narrative)

A significant folding-back moment occurs on Page 05 when the student struggles with understanding the complexity of gravitational perturbations in celestial mechanics. Initially, the student attempts to articulate the influence of other planets on the orbital path, which indicates a move from Image-Having to Property-Noticing. However, the AI prompts the student to reconsider the computational impracticality of solving the \(N\)-body problem, leading the student to fold back to Image-Making. This recursive process helps the student reconstruct their understanding by focusing on the practical limitations of direct solutions and the necessity of approximation methods like Taylor polynomials.

---

## 4) PK layer coding (evidence-rich)

| Layer             | Evidence from transcript | Notes on classification |
| ----------------- | ------------------------ | ----------------------- |
| Primitive Knowing | Initial mention of Taylor polynomials | Basic awareness of the concept |
| Image-Making      | Describing real-world problems | Creating mental images of scenarios |
| Image-Having      | Identifying gravitational perturbations | Holding a mental image of the problem |
| Property-Noticing | Recognizing computational limits | Noticing specific properties of the problem |
| Formalising       | Discussing Taylor series terms | Structuring understanding into formal concepts |
| Observing         | Reflecting on Taylor series utility | Observing the broader application of concepts |
| Structuring       | Synthesizing precision vs. computation | Structuring knowledge into a coherent framework |
| Inventising       | Proposing Taylor-based systems | Innovating with learned concepts |

---

## 5) Page-by-page PK-WAP coding

| Page | Dominant layer(s) | Representative evidence | Notes |
| ---: | ----------------- | ----------------------- | ----- |
|    00 | Primitive Knowing | Mention of Taylor polynomials | Initial awareness |
|    01 | Image-Making | Describing a real-world problem | Creating mental scenarios |
|    02 | Image-Having | Preferring concise explanations | Holding mental images |
|    03 | Image-Making | Breaking problems into steps | Further scenario creation |
|    04 | Property-Noticing | Identifying gravitational influences | Noticing problem properties |
|    05 | Formalising | Discussing computational impracticality | Structuring understanding |
|    06 | Formalising | Analyzing Taylor series terms | Deepening formal understanding |
|    07 | Observing | Reflecting on Taylor series utility | Observing broader applications |
|    08 | Structuring | Synthesizing knowledge | Coherent knowledge framework |
|    09 | Structuring | Discussing precision vs. computation | Structuring complex ideas |
|    10 | Inventising | Proposing new systems | Innovating with concepts |
|    11 | Inventising | Designing Taylor-based systems | Applying knowledge creatively |
|    12 | Inventising | Discussing trade-offs in design | Further innovation |
|    13 | Inventising | Reflecting on engineering applications | Final synthesis |
|    14 | Inventising | Concluding reflections | Summarizing learning |

---

## 6) Representative quotes

**Student:**
1. "model the track of a planet" (Page 04) - Initiating problem exploration.
2. "there are too many other planets will influence the gravity field" (Page 05) - Recognizing complexity.
3. "step3: the error is 6.5meter it is acceptable" (Page 11) - Evaluating approximation accuracy.
4. "taylor series can lower the pressure when calculate things in engineering field" (Page 13) - Synthesizing understanding.

**AI:**
1. "Let's dive into Taylor polynomials with some historical context" (Page 01) - Setting the stage.
2. "Excellent. You've identified gravitational perturbations" (Page 05) - Affirming student insight.
3. "Your Step 3 is mathematically incorrect. Let's fix this systematically" (Page 07) - Providing corrective feedback.
4. "Taylor's power: For a 3rd-degree polynomial in 3D, you store 12 numbers" (Page 12) - Explaining computational efficiency.
5. "Reflect: How does this exercise change your view of Taylor series" (Page 12) - Encouraging reflection.
6. "Could you design a Taylor-based system for a drone avoiding a sudden obstacle?" (Page 13) - Challenging application.

---

## 7) Missed opportunities (elaborated)

1. **Page 04:** The AI could have prompted the student to explore specific examples of gravitational perturbations, deepening their understanding of the problem's complexity.
2. **Page 06:** The AI missed an opportunity to connect the student's understanding of computational limits to real-world engineering constraints, which could have enriched their practical knowledge.
3. **Page 08:** The AI could have encouraged the student to consider alternative approximation methods, broadening their perspective on problem-solving strategies.
4. **Page 10:** The AI could have facilitated a discussion on the trade-offs between precision and computational speed, enhancing the student's critical thinking skills.
5. **Page 12:** The AI could have asked the student to reflect on how Taylor series might apply to other fields, fostering interdisciplinary connections.

---

## 8) Summary of Findings

The dialogue between the student and AI demonstrates a progression through the Pirie-Kieren layers, with notable folding-back moments that facilitate deeper understanding. The student's engagement is characterized by a preference for concise explanations and a focus on practical applications, as evidenced by their reflections on the utility of Taylor series in engineering contexts. The AI effectively guides the student through problem-solving steps, although there are missed opportunities for deeper exploration and interdisciplinary connections. Overall, the interaction highlights the student's growth in formalizing and structuring their understanding of Taylor polynomials, culminating in innovative applications.

---

## 9) Final observations

The PK movement in this dialogue illustrates the student's journey from basic awareness to innovative application, with the AI playing a crucial role in scaffolding this progression. The tone is serious and focused, aligning with the student's preferences, and the interaction fosters a sense of agency as the student navigates complex mathematical concepts. Future improvements could include more explicit connections to real-world applications and interdisciplinary contexts, enhancing the student's ability to transfer knowledge across domains.

---

## 10) Conclusion

This case underscores the importance of recursive understanding in mathematical cognition, as evidenced by the student's folding-back moments and subsequent growth. The PK trajectory from Primitive Knowing to Inventising highlights the potential for AI-guided dialogue to facilitate deep learning and innovative thinking. The pedagogical implications suggest that tailored AI interactions can effectively support students in navigating complex mathematical concepts, provided that opportunities for deeper exploration and interdisciplinary connections are leveraged.