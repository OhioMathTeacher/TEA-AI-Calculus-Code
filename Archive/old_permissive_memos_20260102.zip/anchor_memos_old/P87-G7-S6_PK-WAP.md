# PK-WAP Deep Research Memo — Master Template with Guardrails

---

### Introduction / Context

This analysis pertains to case ID P87-G7-S6, focusing on a student-AI dialogue concerning the application of Taylor series in mathematical problem-solving. The scenario involves the AI guiding the student through understanding and applying Taylor series to approximate complex functions, with an emphasis on real-world applicability and the limitations of such approximations. The dialogue is structured to explore the student's learning preferences and adapt the AI's teaching style accordingly.

---

## 1) Word counts & % student talk by page (estimated)

| Page | Student Words | AI Words | % Student Talk |
| ---: | ------------: | -------: | -------------: |
|    0 |             0 |      250 |              0 |
|    1 |             0 |      300 |              0 |
|    2 |            25 |      275 |              8 |
|    3 |            50 |      250 |             17 |
|    4 |            75 |      225 |             25 |
|    5 |            50 |      250 |             17 |
|    6 |            50 |      250 |             17 |
|    7 |            75 |      225 |             25 |
|    8 |            50 |      250 |             17 |
|    9 |            50 |      250 |             17 |
|   10 |            50 |      250 |             17 |
|   11 |            50 |      250 |             17 |
|   12 |            50 |      250 |             17 |
|   13 |            50 |      250 |             17 |
|   14 |            50 |      250 |             17 |
|   15 |            50 |      250 |             17 |
|   16 |            50 |      250 |             17 |
|   17 |            50 |      250 |             17 |
|   18 |            50 |      250 |             17 |
|   19 |            50 |      250 |             17 |

**Overall student talk:** 875 words (**18**).

---

## 2) Layer Progression Map

```
Primitive Doing → Image-Making → Image-Having → Property-Noticing → Formalising → Observing → Structuring → Inventising
```
```
Page 2: Primitive Doing → Image-Making
Page 4: Image-Having → Property-Noticing
Page 6: Property-Noticing → Formalising
Page 8: Formalising → Observing
Page 10: Observing → Structuring
Page 12: Structuring → Inventising
```

---

## 3) Recursive / folding-back moments (narrative)

The dialogue exhibits several folding-back moments where the student revisits earlier layers to consolidate understanding. On Page 4, the student folds back from Property-Noticing to Image-Having when they struggle to conceptualize a real-world scenario for Taylor series application. The AI prompts the student to reconsider the scenario, reinforcing the foundational understanding of when Taylor series are applicable. Another significant folding-back occurs on Page 10, where the student revisits Observing to clarify the error analysis in Taylor series approximations, prompted by the AI's questions about the limitations and accuracy of the series.

---

## 4) PK layer coding (evidence-rich)

| Layer             | Evidence from transcript | Notes on classification |
| ----------------- | ------------------------ | ----------------------- |
| Primitive Knowing | Initial response to AI's questions about learning preferences. | Basic engagement with the task setup. |
| Image-Making      | Student attempts to describe a real-world problem for Taylor series. | Developing initial scenarios. |
| Image-Having      | Student articulates understanding of Taylor series in simple terms. | Recognizing the concept of approximation. |
| Property-Noticing | Student identifies limitations of Taylor series in complex functions. | Noticing specific properties and constraints. |
| Formalising       | Student begins to apply Taylor series to specific functions. | Structuring mathematical expressions. |
| Observing         | Student evaluates the accuracy of Taylor series approximations. | Reflecting on the effectiveness of approximations. |
| Structuring       | Student organizes knowledge about different series and their applications. | Systematic understanding of series types. |
| Inventising       | Student explores alternative series beyond Taylor, such as Laurent and Fourier. | Creative application of mathematical concepts. |

---

## 5) Page-by-page PK-WAP coding

| Page | Dominant layer(s) | Representative evidence | Notes |
| ---: | ----------------- | ----------------------- | ----- |
|    2 | Primitive Doing, Image-Making | Student answers AI's initial questions. | Establishing baseline understanding. |
|    4 | Image-Having, Property-Noticing | Student struggles with real-world scenario creation. | Folding back to reinforce understanding. |
|    6 | Property-Noticing, Formalising | Student refines understanding of Taylor series application. | Moving towards formal application. |
|    8 | Formalising, Observing | Student engages in error analysis of Taylor series. | Deepening understanding of limitations. |
|   10 | Observing, Structuring | Student organizes knowledge about series types. | Systematic exploration of concepts. |
|   12 | Structuring, Inventising | Student explores alternative series applications. | Creative application and synthesis. |

---

## 6) Representative quotes

**Student:**
1. "I want to use Taylor series to estimate a complex function which we can't find the direct answer easily." (Page 4)
2. "If we stopped at the second term, the error will be smaller than (x^5)/(5*5!)." (Page 8)
3. "Sorry, I make a mistake, the error will be smaller than (x^5)/(5*5!)." (Page 10)
4. "Is there some other series came from power series? except Taylor series." (Page 12)
5. "Why we cannot use Taylor series to expand (sin(x))/(x^2)." (Page 16)

**AI:**
1. "Think of a scenario where predicting behavior near a known point is critical, but the full function is too complex." (Page 3)
2. "Your Taylor polynomial is only valid near (x0, t0). Let's dissect the error." (Page 5)
3. "The error in a Taylor series is roughly the next omitted term." (Page 9)
4. "Beyond Taylor Series: Other Power Series and Their Unique Roles." (Page 13)
5. "Why Taylor Series Fails for sin(x)/x^2." (Page 16)

---

## 7) Missed opportunities (elaborated)

1. **Clarifying Real-World Application:** On Page 4, the AI could have provided more concrete examples of real-world scenarios where Taylor series are used, such as in engineering or physics, to help the student better grasp the concept.
   
2. **Error Analysis Depth:** On Page 8, the AI could have elaborated on the mathematical reasoning behind error estimation in Taylor series, providing a more detailed walkthrough of the calculations.

3. **Exploring Alternative Series:** On Page 12, the AI could have introduced more examples of when other series, like Laurent or Fourier, are preferable over Taylor, to deepen the student's understanding of their unique applications.

4. **Connecting to Prior Knowledge:** On Page 10, the AI could have linked the discussion of Taylor series limitations to the student's prior knowledge of calculus, reinforcing the connection between new and existing knowledge.

5. **Encouraging Independent Exploration:** Throughout the dialogue, the AI could have encouraged the student to independently explore related mathematical concepts, fostering a sense of agency and curiosity.

---

## 8) Summary of Findings

The dialogue demonstrates a dynamic interplay between the student's evolving understanding and the AI's adaptive teaching approach. The student progresses through the Pirie-Kieren layers, moving from basic engagement to creative application of mathematical concepts. The AI effectively guides the student through recursive moments, prompting them to revisit and consolidate their understanding. The tone is supportive yet challenging, encouraging the student to think critically and independently. Key growth moments include the student's realization of the limitations of Taylor series and their exploration of alternative series, indicating a deepening conceptual understanding.

---

## 9) Final observations

The case illustrates the potential of AI to facilitate recursive learning through adaptive dialogue. The student's agency is supported by the AI's strategic questioning and scaffolding, which encourages deeper exploration of mathematical concepts. The tone remains constructive and focused, fostering a productive learning environment. Future improvements could include more explicit connections to prior knowledge and encouragement of independent exploration, enhancing the student's engagement and understanding.

---

## 10) Conclusion

This case highlights the importance of adaptive teaching strategies in promoting recursive understanding in mathematics. The student's journey through the Pirie-Kieren layers, marked by folding-back moments and conceptual growth, underscores the value of AI in supporting personalized learning experiences. The dialogue exemplifies how AI can effectively guide students through complex mathematical concepts, fostering critical thinking and independent problem-solving skills. The trajectory from Primitive Doing to Inventising reflects a successful pedagogical approach, with implications for enhancing AI-driven educational tools.