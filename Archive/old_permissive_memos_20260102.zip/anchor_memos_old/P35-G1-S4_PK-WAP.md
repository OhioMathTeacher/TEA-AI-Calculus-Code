# PK-WAP Deep Research Memo — Master Template with Guardrails

---

### Introduction / Context

This analysis pertains to case ID P35-G1-S4, focusing on a student-AI dialogue centered around the application of Taylor polynomials to approximate complex functions. The student engages with an AI designed to adapt its teaching style based on a preliminary personality test. The dialogue explores the mathematical concept of Taylor series, with particular attention to real-world applications and the limitations of polynomial approximations.

---

## 1) Word counts & % student talk by page (estimated)

| Page | Student Words | AI Words | % Student Talk |
| ---: | ------------: | -------: | -------------: |
|    00 |             0 |      210 |              0 |
|    01 |            14 |      286 |              5 |
|    02 |             0 |      180 |              0 |
|    03 |            28 |      372 |              7 |
|    04 |            25 |      350 |              7 |
|    05 |            18 |      350 |              5 |
|    06 |            20 |      350 |              5 |
|    07 |           185 |      350 |             35 |
|    08 |             0 |      350 |              0 |

**Overall student talk:** 290 words (**8**).

---

## 2) Layer Progression Map

```
Primitive Doing → Image-Making → Image-Having → Property-Noticing → Formalising
                      ↘︎
                      ↘︎ Folding-back (Page 03)
                      ↘︎
                      ↘︎ Property-Noticing → Formalising → Observing → Structuring
```

---

## 3) Recursive / folding-back moments (narrative)

A significant folding-back moment occurs on Page 03 when the student initially struggles to articulate a real-world scenario for Taylor approximation. The AI prompts the student to refine their example, leading to a deeper engagement with the concept of approximation. This folding-back from Image-Having to Property-Noticing allows the student to reconstruct their understanding by considering the practical constraints of using exact functions in real-world scenarios.

---

## 4) PK layer coding (evidence-rich)

| Layer             | Evidence from transcript | Notes on classification |
| ----------------- | ------------------------ | ----------------------- |
| Primitive Knowing | Initial understanding of Taylor series | Basic awareness of the concept |
| Image-Making      | Describing bacteria growth scenario | Creating mental images of application |
| Image-Having      | "Measure the number of bacteria reproducing in an area." | Holding a mental image of the problem |
| Property-Noticing | Recognizing calculation difficulty | Noticing specific properties of the function |
| Formalising       | Writing Taylor series terms | Formal mathematical expression |
| Observing         | Comparing approximation to exact values | Observing discrepancies and errors |
| Structuring       | Understanding limitations of approximation | Structuring knowledge about convergence |
| Inventising       | Not reached in this transcript | No evidence of inventising |

---

## 5) Page-by-page PK-WAP coding

| Page | Dominant layer(s) | Representative evidence | Notes |
| ---: | ----------------- | ----------------------- | ----- |
|    00 | Primitive Knowing | Introduction to Taylor series | Setting the stage for learning |
|    01 | Image-Making | "Think of a situation where predicting behavior near a known point matters..." | Encouraging scenario creation |
|    02 | Image-Having | "Measure the number of bacteria reproducing in an area." | Student holds a mental image |
|    03 | Property-Noticing | "Why is this function problematic for quick predictions?" | Noticing function properties |
|    04 | Formalising | Writing Taylor series terms | Engaging in formal mathematical processes |
|    05 | Observing | Comparing approximation to exact values | Observing and analyzing results |
|    06 | Structuring | Understanding limitations of approximation | Structuring understanding of convergence |
|    07 | Structuring | "Taylor polynomial is an approximation constructed based on the derivative information..." | Deepening understanding of limitations |
|    08 | Structuring | "Radius of convergence R = 1." | Final synthesis of understanding |

---

## 6) Representative quotes

**Student:**
1. "Measure the number of bacteria reproducing in an area." (Page 03) - Illustrates initial scenario creation.
2. "The first three terms of the Taylor series expansion..." (Page 04) - Demonstrates formalising.
3. "The approximate value is 1.02045, and the percentage error..." (Page 06) - Shows observation and analysis.
4. "The Taylor polynomial is an approximation constructed based on the derivative information..." (Page 07) - Reflects deep understanding of limitations.

**AI:**
1. "Imagine you’re an 18th-century scientist tracking a comet’s path..." (Page 02) - Sets historical context.
2. "Why is this function problematic for quick predictions?" (Page 03) - Prompts deeper thinking.
3. "Let’s approximate \( f(t) \) near \( t = 0 \)..." (Page 04) - Guides formalising process.
4. "For tiny \( t \) (like 0.1 hours), Taylor approximations are fantastic." (Page 06) - Reinforces observation.
5. "Why does the Taylor polynomial fail spectacularly at \( t = 2 \)?" (Page 07) - Encourages critical thinking.

---

## 7) Missed opportunities (elaborated)

1. **Exploration of Inventising:** The AI could have prompted the student to explore potential new applications of Taylor series, encouraging inventising.
2. **Deeper Error Analysis:** The AI could have guided the student to explore the implications of errors in real-world scenarios, deepening understanding.
3. **Connection to Other Mathematical Concepts:** The AI missed the opportunity to connect Taylor series to other areas of calculus, such as integration or differential equations.
4. **Encouragement of Independent Exploration:** The AI could have encouraged the student to independently explore Taylor series in different contexts, fostering autonomy.
5. **Reflection on Learning Process:** The AI could have prompted the student to reflect more deeply on their learning process and how their understanding evolved.

---

## 8) Summary of Findings

The dialogue demonstrates a structured progression through the Pirie-Kieren layers, with the student moving from Primitive Knowing to Structuring. The AI effectively scaffolds the student's understanding, particularly through folding-back moments that deepen engagement with the material. The tone is supportive and adaptive, aligning with the student's preferences for direct explanations and structured guidance. Key growth moments include the student's realization of the limitations of Taylor approximations and their ability to articulate these limitations clearly.

---

## 9) Final observations

The student exhibits significant conceptual growth, particularly in understanding the practical applications and limitations of Taylor series. The AI's use of structured guidance and direct corrections aligns well with the student's learning preferences, though opportunities for deeper exploration and connection to broader mathematical concepts were missed. The dialogue reflects a positive learning environment, with the student demonstrating agency in their learning process.

---

## 10) Conclusion

This case highlights the importance of adaptive teaching strategies in facilitating deep mathematical understanding. The student's journey through the Pirie-Kieren layers illustrates the recursive nature of learning, with folding-back moments playing a crucial role in reconstructing understanding. The dialogue underscores the value of tailored AI support in enhancing student engagement and conceptual growth, with implications for future educational technology development.