# PK-WAP Deep Research Memo — Master Template with Guardrails

---

### Introduction / Context

This analysis pertains to transcript P118-G7-S4, which involves a student engaging with an AI in a dialogue designed to explore the student's preferred learning style and apply it to a mathematical scenario involving Taylor polynomials. The dialogue begins with the AI profiling the student's ideal teacher and then transitions into a mathematical activity focused on real-world applications of Taylor polynomials. The analysis will explore the student's recursive understanding and conceptual growth through the Pirie-Kieren framework.

---

## 1) Word counts & % student talk by page (estimated)

| Page | Student Words | AI Words | % Student Talk |
| ---: | ------------: | -------: | -------------: |
|    1 |            97 |      122 |             44 |
|    2 |           112 |      135 |             45 |
|    3 |           134 |      148 |             48 |
|    4 |            89 |      160 |             36 |

**Overall student talk:** 432 words (**43**).

---

## 2) Layer Progression Map

```
Primitive Doing → Image-Making → Image-Having → Property-Noticing ↷ 
                                                      ↖ Formalising → Observing → Structuring → Inventising
```

---

## 3) Recursive / folding-back moments (narrative)

A significant folding-back moment occurs on page 3, where the student revisits their understanding of exponential functions in the context of GDP growth. Initially, the student identifies the complexity of predicting economic growth due to unpredictable factors like wars and pandemics. The AI prompts the student to consider the function's limitations over a long-term horizon, leading the student to fold back from Property-Noticing to Image-Having. This recursive process allows the student to refine their understanding of why a simple exponential model fails, ultimately progressing towards a more nuanced grasp of Taylor approximations.

---

## 4) PK layer coding (evidence-rich)

| Layer             | Evidence from transcript                                                                 | Notes on classification                         |
| ----------------- | ---------------------------------------------------------------------------------------- | ----------------------------------------------- |
| Primitive Knowing | Student identifies GDP growth as a complex problem.                                      | Initial recognition of a real-world problem.    |
| Image-Making      | Student considers factors like wars and pandemics affecting GDP.                         | Developing a mental image of influencing factors.|
| Image-Having      | Student articulates why these factors complicate predictions.                            | Holding a coherent image of the problem's complexity.|
| Property-Noticing | Student notes the failure of simple exponential models over long periods.                | Recognizing specific properties of the function.|
| Formalising       | Student attempts to express GDP growth in mathematical terms.                            | Transitioning to formal mathematical expression.|
| Observing         | Student acknowledges the utility of Taylor approximations despite limitations.           | Observing broader applicability of approximations.|
| Structuring       | Student derives a Taylor approximation for GDP growth.                                   | Structuring mathematical reasoning.             |
| Inventising       | Student defends the use of approximations in real-world decision-making.                 | Innovating within the mathematical framework.   |

---

## 5) Page-by-page PK-WAP coding

| Page | Dominant layer(s) | Representative evidence                                                                 | Notes                                       |
| ---: | ----------------- | ---------------------------------------------------------------------------------------- | ------------------------------------------- |
|    1 | Primitive Knowing | "I think it is impossible to predict the long-term economic growth..."                   | Initial problem identification.             |
|    2 | Image-Making      | "For example, after COVID-19, the economy for the whole world has been influenced..."    | Developing a contextual image.              |
|    3 | Property-Noticing | "For a long term like 50 years, the growth rate of k would be almost impossible not to change..." | Recognizing function limitations.           |
|    4 | Formalising       | "The Taylor approximation above is Ae^kt = Ae^kt_0 [1+k(t-t_0)]"                        | Formalizing understanding through derivation.|

---

## 6) Representative quotes

**Student:**
1. "I prefer direct, concise explanations." (Page 1) - Reflects initial learning preference.
2. "I think it is impossible to predict the long-term economic growth..." (Page 1) - Identifies a complex problem.
3. "For example, after COVID-19, the economy for the whole world has been influenced..." (Page 2) - Provides real-world context.
4. "For a long term like 50 years, the growth rate of k would be almost impossible not to change..." (Page 3) - Recognizes limitations of models.
5. "The Taylor approximation above is Ae^kt = Ae^kt_0 [1+k(t-t_0)]" (Page 4) - Demonstrates formal mathematical reasoning.

**AI:**
1. "Your Ideal Teacher: Tone & Energy: Direct and efficient..." (Page 1) - Establishes the teaching profile.
2. "GDP growth? Ambitious. But Hua Luogeng would ask: What’s the function hiding here?" (Page 2) - Challenges the student to think deeper.
3. "You’re right—no function can predict pandemics. But let’s isolate the mathematical heart of the problem." (Page 3) - Guides the student to focus on core issues.
4. "Your approximation is linear: GDP(t)≈Ae^kt_0[1+k(t−t_0)]. Now, the hard questions:" (Page 4) - Encourages critical evaluation of approximations.
5. "All models are wrong—but some are useful." (Page 4) - Emphasizes pragmatic use of models.

---

## 7) Missed opportunities (elaborated)

1. **Exploration of Non-linear Models:** The AI could have prompted the student to explore non-linear models beyond exponential functions, deepening their understanding of complex systems.
   
2. **Connection to Historical Context:** The AI mentioned historical figures but did not fully leverage this to connect mathematical concepts to historical applications, which could have enriched the learning experience.

3. **Encouragement of Multiple Approximations:** The AI could have encouraged the student to derive multiple Taylor approximations for different scenarios, fostering a deeper exploration of the concept.

---

## 8) Summary of Findings

The dialogue reveals a student actively engaging with complex mathematical concepts through a structured interaction with the AI. The student demonstrates growth from Primitive Knowing to Inventising, with notable recursive moments that deepen their understanding of Taylor polynomials in real-world contexts. The tone is collaborative, with the AI providing both challenges and support, fostering an environment conducive to conceptual growth. Key growth moments include the student's recognition of the limitations of exponential models and their successful derivation of a Taylor approximation.

---

## 9) Final observations

The student's journey through the Pirie-Kieren layers illustrates a dynamic interplay between agency and guidance, with the AI effectively scaffolding the student's exploration of mathematical concepts. The dialogue maintains a balance between challenge and support, encouraging the student to articulate and refine their understanding. Future interactions could benefit from more explicit connections to historical applications and encouragement of diverse mathematical approaches.

---

## 10) Conclusion

This case highlights the potential of AI-facilitated dialogue to support deep mathematical understanding through the Pirie-Kieren framework. The student's trajectory from Primitive Knowing to Inventising underscores the importance of recursive learning and the effective use of approximations in complex problem-solving. This analysis suggests that AI can play a pivotal role in fostering mathematical cognition, provided it leverages opportunities for deeper exploration and contextual connections.