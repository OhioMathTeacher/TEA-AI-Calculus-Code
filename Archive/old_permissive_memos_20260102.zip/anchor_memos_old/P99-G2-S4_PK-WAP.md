# PK-WAP Deep Research Memo — Master Template with Guardrails

---

### Introduction / Context

This analysis pertains to case ID P99-G2-S4, focusing on a student-AI dialogue centered around the application of Taylor polynomials in engineering contexts. The scenario involves the student constructing a Taylor polynomial to approximate the Fermi-Dirac distribution for semiconductor conductivity, highlighting computational constraints in real-time systems. Unlabeled student turns responding to AI prompts are treated as student turns.

---

## 1) Word counts & % student talk by page (estimated)

| Page | Student Words | AI Words | % Student Talk |
| ---: | ------------: | -------: | -------------: |
|    0 |            10 |       85 |             11 |
|    1 |            10 |       75 |             12 |
|    2 |            10 |      100 |              9 |
|    3 |           210 |       40 |             84 |
|    4 |           120 |       80 |             60 |
|    5 |           180 |       60 |             75 |
|    6 |           150 |       70 |             68 |
|    7 |           200 |       50 |             80 |
|    8 |           250 |       50 |             83 |
|    9 |           100 |       90 |             53 |
|   10 |           150 |       50 |             75 |
|   11 |           150 |       50 |             75 |
|   12 |           200 |       50 |             80 |
|   13 |           100 |       80 |             56 |
|   14 |            50 |       50 |             50 |

**Overall student talk:** 1,890 words (**63**).

---

## 2) Layer Progression Map

```
Primitive Doing → Image-Making → Image-Having → Property-Noticing → Formalising
    ↘︎ (Page 3) ↗︎
Observing → Structuring → Inventising
```

---

## 3) Recursive / folding-back moments (narrative)

A significant folding-back moment occurs on Page 3, where the student revisits the complexity of the Fermi-Dirac distribution to identify computational bottlenecks. Initially operating at the Property-Noticing layer, the student folds back to Image-Making to reconstruct understanding by isolating the exponential term as computationally expensive. This recursive process allows the student to refine their approach, moving forward with a clearer focus on the task requirements.

Another folding-back instance is observed on Page 5, where the student, after identifying the computationally expensive part, revisits the temperature range for Taylor expansion. This involves a transition from Formalising back to Image-Having, as the student reassesses the physical implications of their mathematical choices, ensuring the proposed range is both mathematically sound and practically relevant.

---

## 4) PK layer coding (evidence-rich)

| Layer             | Evidence from transcript | Notes on classification |
| ----------------- | ------------------------ | ----------------------- |
| Primitive Knowing | Prefers direct explanations (Page 0) | Initial preferences indicate basic engagement with learning styles. |
| Image-Making      | Proposes semiconductor scenario (Page 2) | Constructs a scenario to apply Taylor polynomials. |
| Image-Having      | Describes computational cost (Page 3) | Holds a mental image of the problem's complexity. |
| Property-Noticing | Identifies exponential term as costly (Page 5) | Notices specific properties of the function affecting computation. |
| Formalising       | Proposes temperature range (Page 5) | Formalizes understanding into a specific range for approximation. |
| Observing         | Calculates Taylor polynomial (Page 7) | Observes mathematical relationships through derivative calculations. |
| Structuring       | Analyzes polynomial accuracy (Page 9) | Structures understanding by quantifying error and limitations. |
| Inventising       | Reflects on Taylor series as an engineering tool (Page 12) | Innovates understanding of Taylor series beyond theoretical use. |

---

## 5) Page-by-page PK-WAP coding

| Page | Dominant layer(s) | Representative evidence | Notes |
| ---: | ----------------- | ----------------------- | ----- |
|    0 | Primitive Knowing | Prefers direct explanations | Establishes initial learning preferences. |
|    1 | Primitive Knowing | Mentions Ronaldo for strict teaching | Indicates preference for structured learning. |
|    2 | Image-Making      | Proposes semiconductor scenario | Engages in scenario construction. |
|    3 | Image-Having      | Describes computational cost | Develops a mental model of the problem. |
|    4 | Property-Noticing | Identifies exponential term as costly | Focuses on specific function properties. |
|    5 | Formalising       | Proposes temperature range | Formalizes a mathematical approach. |
|    6 | Observing         | Begins Taylor polynomial calculation | Engages in detailed mathematical observation. |
|    7 | Observing         | Continues polynomial calculation | Deepens observation through derivatives. |
|    8 | Structuring       | Completes polynomial and explains coefficients | Structures understanding of polynomial components. |
|    9 | Structuring       | Analyzes polynomial accuracy | Quantifies error and assesses limitations. |
|   10 | Structuring       | Continues error analysis | Further structures understanding of polynomial limits. |
|   11 | Inventising       | Reflects on Taylor series application | Innovates understanding of mathematical tools. |
|   12 | Inventising       | Reflects on AI teacher's role | Considers broader implications of learning process. |
|   13 | Inventising       | Plans future application of learning | Projects learning into future contexts. |
|   14 | Inventising       | Identifies approach flaw and improvement | Innovates by identifying and planning to address gaps. |

---

## 6) Representative quotes

**Student:**
1. "The main reason engineers can't use the exact function is the high computational cost." (Page 3)
2. "For the Taylor expansion around the fixed temperature T_O = 300K, a suitable temperature range could be 280K - 320K." (Page 5)
3. "Before constructing this approximation, I mainly regarded the Taylor series as an abstract mathematical tool." (Page 12)
4. "In my next project involving real-time system performance optimization, I'll use Taylor polynomial approximation." (Page 13)

**AI:**
1. "Good. Semiconductor conductivity depends on temperature via the Fermi-Dirac distribution." (Page 2)
2. "Precision. That’s the discipline. You've identified the bottleneck." (Page 3)
3. "Correct. You've targeted the exponential term as the bottleneck and proposed a 40K range around 300K." (Page 5)
4. "This isn’t just math—it’s engineering survival." (Page 7)

---

## 7) Missed opportunities (elaborated)

1. **Deeper Exploration of Physical Context:** On Page 5, the AI could have prompted the student to explore the physical implications of the temperature range more deeply, enhancing the connection between mathematical approximation and real-world application.
   
2. **Encouraging Alternative Approaches:** On Page 6, the AI could have encouraged the student to consider alternative methods for simplifying the Fermi-Dirac function, potentially broadening the student's problem-solving toolkit.

3. **Reflective Practice on Error Analysis:** On Page 10, the AI could have guided the student to reflect on the implications of the error analysis for practical engineering decisions, fostering a deeper understanding of the trade-offs involved.

---

## 8) Summary of Findings

The dialogue demonstrates a high level of student engagement, with significant movement through the Pirie-Kieren layers from Primitive Knowing to Inventising. The student exhibits agency in constructing and refining their understanding of Taylor polynomials, particularly in the context of engineering applications. The tone is disciplined and focused, reflecting the structured approach favored by the student. Key growth moments include the realization of Taylor series as an engineering tool and the ability to quantify and analyze approximation errors.

---

## 9) Final observations

The student's journey through the PK layers highlights a robust engagement with mathematical concepts, facilitated by the AI's structured guidance. The disciplined tone, akin to a coaching style, supports the student's development of a rigorous and systematic approach to problem-solving. Opportunities for improvement include fostering deeper connections between mathematical and physical contexts and encouraging reflective practice on the implications of error analysis.

---

## 10) Conclusion

This case illustrates the transformative potential of structured AI guidance in mathematical learning, as evidenced by the student's progression through the PK layers. The trajectory from Primitive Knowing to Inventising underscores the importance of connecting mathematical tools to real-world applications. The pedagogical implications suggest that AI can effectively scaffold student learning by balancing discipline with opportunities for creative exploration.