# PK-WAP Deep Research Memo — Master Template with Guardrails

---

### Introduction / Context

This analysis pertains to transcript P86-G13-S4, employing the Pirie-Kieren Work Analysis Protocol (PK-WAP) to examine a student-AI dialogue focused on constructing a real-world scenario where a Taylor polynomial approximation is the only practical solution. The dialogue involves the AI guiding the student through a structured activity, emphasizing the student's agency in problem-solving while the AI provides nudges and prompts without giving direct answers. Unlabeled student turns that answer AI prompts are treated as student turns.

---

## 1) Word counts & % student talk by page (estimated)

| Page | Student Words | AI Words | % Student Talk |
| ---: | ------------: | -------: | -------------: |
|    1 |            21 |       92 |             19 |
|    2 |            15 |       85 |             15 |
|    3 |            14 |       95 |             13 |
|    4 |            23 |       87 |             21 |
|    5 |            11 |       89 |             11 |
|    6 |            18 |       82 |             18 |
|    7 |            12 |       88 |             12 |
|    8 |            17 |       83 |             17 |

**Overall student talk:** 131 words (**16**).

---

## 2) Layer Progression Map

```
Primitive Doing → Image-Making → Image-Having → Property-Noticing
                      ↘︎
                   Formalising → Observing → Structuring → Inventising
```

---

## 3) Recursive / folding-back moments (narrative)

The dialogue exhibits several folding-back moments, notably when the student revisits their understanding of polynomial degree choice. Initially, the student suggests using a simpler function due to complexity (Page 6), indicating a transition from Image-Having to Property-Noticing. The AI's prompts lead the student to reconsider the adequacy of a linear approximation, prompting a fold-back to Image-Making as they explore the implications of polynomial degree on approximation accuracy (Page 8). This recursive process helps the student refine their understanding of the trade-offs involved in approximation.

---

## 4) PK layer coding (evidence-rich)

| Layer             | Evidence from transcript | Notes on classification |
| ----------------- | ------------------------ | ----------------------- |
| Primitive Knowing | "I prefer direct, structured explanations." | Initial preferences indicate basic understanding. |
| Image-Making      | "Why can’t this system be measured or calculated directly?" | Student begins to visualize the problem context. |
| Image-Having      | "Since the uneven material, it is really complex to build up a model to describe." | Student holds a mental image of the problem's complexity. |
| Property-Noticing | "Degree 1 clearly is not enough." | Recognizes limitations of linear approximation. |
| Formalising       | "Try degree 2 (quadratic): Captures acceleration in heat loss." | Moves towards formalizing the approximation strategy. |
| Observing         | "What’s the physical cost of higher degrees?" | Considers implications of polynomial degree on computation. |
| Structuring       | "Would you sacrifice speed for accuracy with degree 3?" | Begins structuring decision-making around trade-offs. |
| Inventising       | "In industry, 5% error might be tolerable." | Innovates by setting practical error thresholds. |

---

## 5) Page-by-page PK-WAP coding

| Page | Dominant layer(s) | Representative evidence | Notes |
| ---: | ----------------- | ----------------------- | ----- |
|    1 | Primitive Knowing | "I prefer direct, structured explanations." | Establishes initial learning preferences. |
|    2 | Image-Making      | "Why can’t this system be measured or calculated directly?" | Begins to engage with problem context. |
|    3 | Image-Having      | "Since the uneven material, it is really complex to build up a model to describe." | Holds a mental model of the problem. |
|    4 | Property-Noticing | "Degree 1 clearly is not enough." | Identifies inadequacy of a simple solution. |
|    5 | Formalising       | "Try degree 2 (quadratic): Captures acceleration in heat loss." | Formalizes approach to approximation. |
|    6 | Observing         | "What’s the physical cost of higher degrees?" | Observes computational implications. |
|    7 | Structuring       | "Would you sacrifice speed for accuracy with degree 3?" | Structures decision-making process. |
|    8 | Inventising       | "In industry, 5% error might be tolerable." | Innovates by setting practical thresholds. |

---

## 6) Representative quotes

**Student:**
1. "I prefer direct, structured explanations." (Page 1) - Indicates initial learning style preference.
2. "Why can’t this system be measured or calculated directly?" (Page 2) - Engages with problem complexity.
3. "Since the uneven material, it is really complex to build up a model to describe." (Page 3) - Visualizes problem complexity.
4. "Degree 1 clearly is not enough." (Page 4) - Recognizes limitations of linear approximation.
5. "I don't know, but degree1 clearly is not enough." (Page 5) - Reflects on inadequacy of initial approach.
6. "In industry, 5% error might be tolerable." (Page 8) - Innovates by setting practical error thresholds.

**AI:**
1. "Let’s begin with the Personality Test phase." (Page 1) - Sets the stage for understanding student preferences.
2. "Ah, sharp question—let’s break it down together." (Page 2) - Encourages deeper exploration of problem constraints.
3. "Spot-on. Let’s crystallize this." (Page 3) - Acknowledges student insight and guides further.
4. "Try degree 2 (quadratic): Captures acceleration in heat loss." (Page 5) - Suggests a formalized approach to approximation.
5. "Would you sacrifice speed for accuracy with degree 3?" (Page 7) - Challenges student to consider trade-offs.
6. "In industry, 5% error might be tolerable. What’s your threshold?" (Page 8) - Encourages practical application of concepts.

---

## 7) Missed opportunities (elaborated)

1. **Exploration of Historical Context:** The AI could have provided more detailed historical context about Taylor polynomials to enrich the student's understanding of their development and application.
2. **Encouragement of Multiple Scenarios:** The AI could have encouraged the student to explore multiple real-world scenarios to broaden their understanding of where Taylor polynomials are applicable.
3. **Deeper Discussion on Polynomial Degrees:** The AI could have facilitated a deeper discussion on the implications of different polynomial degrees beyond quadratic, enhancing the student's conceptual understanding.
4. **Integration of Visual Aids:** The AI could have suggested the use of visual aids or sketches to help the student better visualize the problem and approximation process.
5. **Reflection on Learning Process:** The AI could have prompted the student to reflect on their learning process and how their understanding evolved throughout the dialogue.

---

## 8) Summary of Findings

The dialogue demonstrates a structured engagement with the mathematical problem of using Taylor polynomials for approximation. The student's progression through the Pirie-Kieren layers is evident, with significant movement from Primitive Knowing to Inventising. The tone is supportive yet challenging, with the AI providing nudges to deepen the student's understanding without giving direct answers. Key growth moments include the student's recognition of the inadequacy of a linear approximation and their innovation in setting practical error thresholds. The dialogue reflects a balance between student agency and AI guidance, fostering a deeper conceptual understanding of the mathematical concepts involved.

---

## 9) Final observations

The PK movement in this dialogue highlights the student's journey from initial preferences to innovative problem-solving. The AI's role in maintaining a focused yet flexible tone allowed the student to explore and refine their understanding of Taylor polynomials. Opportunities for improvement include integrating more historical context and encouraging the exploration of multiple scenarios. Overall, the dialogue effectively supports the student's conceptual growth and agency in problem-solving.

---

## 10) Conclusion

This case illustrates the importance of structured guidance in facilitating deep mathematical understanding. The student's trajectory through the Pirie-Kieren layers, culminating in Inventising, underscores the value of recursive learning and reflection. The dialogue's emphasis on student agency and practical application of concepts provides valuable insights into effective AI-student interactions in mathematical education. The case highlights the potential for AI to support meaningful learning experiences through strategic prompting and scaffolding.

---