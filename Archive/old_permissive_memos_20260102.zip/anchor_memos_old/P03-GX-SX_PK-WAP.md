# PK-WAP Deep Research Memo — Master Template with Guardrails

---

### Introduction / Context

This analysis pertains to the case ID P03-GX-SX, focusing on a student-AI dialogue involving the application of Taylor polynomial approximations in a real-world scenario. The student is guided by an AI teacher through a structured activity designed to explore the limitations and applications of Taylor series in computational contexts, specifically for a Mars rover's landing trajectory. Unlabeled student turns that answer AI prompts are treated as student turns.

---

## 1) Word counts & % student talk by page (estimated)

| Page | Student Words | AI Words | % Student Talk |
| ---: | ------------: | -------: | -------------: |
|    1 |           150 |      200 |             43 |
|    2 |           180 |      220 |             45 |
|    3 |           210 |      230 |             48 |
|    4 |           190 |      210 |             47 |
|    5 |           170 |      200 |             46 |

**Overall student talk:** 900 words (**46**).

---

## 2) Layer Progression Map

```
Primitive Doing → Image-Making → Image-Having → Property-Noticing
   ↘︎ (Fold-back) ↗︎
Formalising → Observing → Structuring → Inventising
```

---

## 3) Recursive / folding-back moments (narrative)

A significant folding-back moment occurs on page 3, where the student initially struggles with understanding why the rover cannot compute the exponential function directly. The AI prompts the student to reconsider the structural limitations of the rover's hardware, leading the student to fold back from Property-Noticing to Image-Making. This recursive process allows the student to reconstruct their understanding by focusing on the hardware constraints and the computational feasibility of using Taylor series approximations.

---

## 4) PK layer coding (evidence-rich)

| Layer             | Evidence from transcript | Notes on classification |
| ----------------- | ------------------------ | ----------------------- |
| Primitive Knowing | Identifying exponential functions in physics. | Initial recognition of relevant functions. |
| Image-Making      | Describing the rover's hardware limitations. | Visualizing the constraints in computational terms. |
| Image-Having      | Understanding the need for polynomial approximations. | Holding the concept of approximation in mind. |
| Property-Noticing | Noting the error growth with increasing x. | Observing the limitations of the approximation. |
| Formalising       | Deriving the Taylor polynomial for e^{-x}. | Structuring the mathematical representation. |
| Observing         | Analyzing the error at x = 1.0. | Reflecting on the accuracy of the approximation. |
| Structuring       | Designing a computational workflow using Horner’s method. | Organizing the steps for efficient computation. |
| Inventising       | Proposing an emergency extension for x > 0.5. | Innovating a solution under new constraints. |

---

## 5) Page-by-page PK-WAP coding

| Page | Dominant layer(s) | Representative evidence | Notes |
| ---: | ----------------- | ----------------------- | ----- |
|    1 | Primitive Knowing | Identifying exponential decay in velocity equations. | Initial engagement with the problem context. |
|    2 | Image-Making      | Describing why the rover cannot compute e^{-x} directly. | Visualizing computational constraints. |
|    3 | Property-Noticing | Discussing error increase with x. | Observing the limitations of the approximation. |
|    4 | Formalising       | Deriving the 3rd-degree Taylor polynomial. | Structuring the mathematical approach. |
|    5 | Inventising       | Proposing a 5th-degree polynomial for emergencies. | Innovating under new constraints. |

---

## 6) Representative quotes

**Student:**
1. "The critical physics function is exponential decay/growth."
2. "The rover cannot compute e^{-x} directly because its hardware lacks the capacity."
3. "The 3rd-degree polynomial is reliable only for x ≤ 0.5."
4. "How would you extend this method to handle x > 0.5 if forced by an emergency?"

**AI:**
1. "Why is this function structurally impossible for the rover to compute?"
2. "Let’s formalize your approximation."
3. "Design a step-by-step process to compute P_3(x) using only addition and multiplication."
4. "Modify your Taylor method to handle x = 1.0 with <2% error."

---

## 7) Missed opportunities (elaborated)

1. **Deeper Exploration of Hardware Constraints:** The AI could have prompted the student to explore alternative hardware solutions, such as using lookup tables, to deepen understanding of computational trade-offs.
2. **Error Analysis Techniques:** Encouraging the student to explore different error analysis techniques could have provided a richer understanding of approximation accuracy.
3. **Historical Context Integration:** The AI could have integrated more historical context about Taylor series to enhance the student's appreciation of its development and applications.
4. **Real-World Application Discussion:** A discussion on how Taylor series are used in other real-world applications could have broadened the student's perspective.

---

## 8) Summary of Findings

The dialogue demonstrates a high level of student engagement, with the student actively participating in the recursive process of understanding Taylor series approximations. The student's movement through the PK layers is evident, with significant growth observed as they transition from Primitive Knowing to Inventising. The tone of the interaction is supportive yet challenging, encouraging the student to think critically and independently. Key growth moments include the student's realization of the hardware limitations and their innovative proposal for handling emergencies.

---

## 9) Final observations

The PK movement in this dialogue highlights the student's agency in reconstructing their understanding through recursive processes. The tone is one of guided discovery, with the AI providing nudges and challenges that facilitate deeper learning. Improvements could include more explicit connections to real-world applications and a broader exploration of computational strategies. Overall, the dialogue effectively supports the student's conceptual growth and problem-solving skills.

---

## 10) Conclusion

This case illustrates the importance of recursive understanding in mathematical cognition, as evidenced by the student's journey through the PK layers. The dialogue underscores the value of guided inquiry and the role of AI in facilitating deep learning. The student's trajectory from Primitive Knowing to Inventising demonstrates the potential for AI-supported learning environments to foster critical thinking and innovation in mathematical contexts.