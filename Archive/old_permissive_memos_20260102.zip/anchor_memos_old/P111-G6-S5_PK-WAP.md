# PK-WAP Deep Research Memo — Master Template with Guardrails

---

### Introduction / Context

This analysis pertains to transcript P111-G6-S5, focusing on a student-AI interaction involving the mathematical concept of Taylor polynomial approximations. The AI's role is to adapt its teaching style based on the student's preferences and guide them through a structured activity. The student is tasked with understanding and applying Taylor polynomials to a real-world engineering problem involving a mountain bike shock absorber. The dialogue is analyzed using the Pirie-Kieren framework to identify recursive understanding and conceptual growth.

---

## 1) Word counts & % student talk by page (estimated)

| Page | Student Words | AI Words | % Student Talk |
| ---: | ------------: | -------: | -------------: |
|    0 |             0 |      150 |              0 |
|    1 |            20 |      180 |             10 |
|    2 |            30 |      170 |             15 |
|    3 |            25 |      175 |             12 |
|    4 |            40 |      160 |             20 |
|    5 |            35 |      165 |             18 |
|    6 |            50 |      150 |             25 |
|    7 |            45 |      155 |             23 |
|    8 |            60 |      140 |             30 |
|    9 |            55 |      145 |             28 |
|   10 |            70 |      130 |             35 |
|   11 |            65 |      135 |             32 |
|   12 |            80 |      120 |             40 |
|   13 |            75 |      125 |             38 |
|   14 |            90 |      110 |             45 |

**Overall student talk:** 740 words (**26**).

---

## 2) Layer Progression Map

```
Primitive Doing → Image-Making → Image-Having → Property-Noticing
     ↘︎ ↖︎
Formalising → Observing → Structuring → Inventising
```

---

## 3) Recursive / folding-back moments (narrative)

One significant folding-back moment occurs on Page 8, where the student struggles with the Taylor expansion of \(e^{-2t}\). Initially, the student attempts to write the expansion but makes errors in the coefficients. The AI prompts the student to revisit the basic form of the Taylor series, leading to a reconstruction of understanding from Image-Having back to Image-Making. This recursive process helps the student correct their misconceptions and solidify their grasp of the expansion process.

Another folding-back instance is observed on Page 10, where the student is asked to multiply the polynomials. The student initially overcomplicates the task, prompting the AI to guide them back to the fundamental multiplication steps, reinforcing the Property-Noticing layer before advancing to Structuring.

---

## 4) PK layer coding (evidence-rich)

| Layer             | Evidence from transcript | Notes on classification |
| ----------------- | ------------------------ | ----------------------- |
| Primitive Knowing | Initial understanding of Taylor series | Basic awareness of the concept |
| Image-Making      | Attempts to write Taylor expansion | Creating mental images of the process |
| Image-Having      | Describes the shock absorber scenario | Retaining and recalling images |
| Property-Noticing | Identifies computational limits | Recognizing specific properties |
| Formalising       | Writes polynomial terms | Applying formal mathematical rules |
| Observing         | Reflects on approximation accuracy | Observing and evaluating outcomes |
| Structuring       | Combines polynomial terms | Organizing mathematical structures |
| Inventising       | Considers error bounds | Engaging in creative mathematical thinking |

---

## 5) Page-by-page PK-WAP coding

| Page | Dominant layer(s) | Representative evidence | Notes |
| ---: | ----------------- | ----------------------- | ----- |
|    0 | Primitive Knowing | Introduction to Taylor series | Establishing baseline knowledge |
|    1 | Image-Making      | Responds to AI's questions | Forming initial images |
|    2 | Image-Having      | Chooses real-world problem | Retaining scenario details |
|    3 | Property-Noticing | Discusses sensor limitations | Noticing computational constraints |
|    4 | Formalising       | Begins Taylor expansion | Formal application of series |
|    5 | Observing         | Evaluates polynomial feasibility | Observing practical implications |
|    6 | Structuring       | Multiplies polynomial terms | Structuring mathematical expressions |
|    7 | Inventising       | Considers error terms | Engaging in inventive thinking |

---

## 6) Representative quotes

**Student:**
1. "Engineering a shock absorber on a mountain bike." (Page 3) - Demonstrates Image-Having.
2. "Let us tighten it further." (Page 4) - Indicates Property-Noticing.
3. "1+0" (Page 6) - Initial attempt at Formalising.
4. "A bit abstract, let's have a concrete example." (Page 5) - Request for clarity.
5. "It clarified my understanding of it." (Page 11) - Reflective Observing.

**AI:**
1. "Newton and Leibniz invented calculus to solve ‘impossible’ problems." (Page 2) - Historical context.
2. "Why can't we just compute F(t)=e—2t-sin(3t) directly?" (Page 4) - Nudge for deeper thinking.
3. "Incorrect. You’re missing the core idea." (Page 8) - Blunt correction.
4. "Does this level of constraint make sense?" (Page 5) - Check-in for understanding.
5. "You now think like an engineer—solving hard problems with imperfect tools." (Page 11) - Encouragement and synthesis.

---

## 7) Missed opportunities (elaborated)

1. **Exploration of Historical Context:** The AI could have expanded on the historical development of Taylor series to enrich the student's understanding of its significance.
   
2. **Deeper Error Analysis:** While the AI prompted the student to consider error bounds, it could have guided them through a more detailed exploration of how these errors impact real-world applications.

3. **Interactive Visual Aids:** Incorporating visual aids or simulations could have helped the student visualize the polynomial approximations and their limitations more effectively.

4. **Connection to Broader Concepts:** The AI missed an opportunity to connect the Taylor series to other areas of calculus, such as integration or differential equations, to provide a more holistic view.

5. **Encouragement of Independent Problem-Solving:** While the AI provided blunt corrections, it could have encouraged the student to explore alternative methods independently before intervening.

---

## 8) Summary of Findings

The student demonstrated significant engagement with the material, moving through multiple layers of the Pirie-Kieren framework. The dialogue was characterized by a direct and efficient tone, reflecting the student's preference for blunt corrections and structured guidance. Key growth moments included the student's ability to reconstruct their understanding of Taylor expansions and apply this knowledge to a practical engineering problem. The recursive nature of the learning process was evident in the student's repeated folding-back to earlier layers, ultimately leading to a deeper understanding of polynomial approximations.

---

## 9) Final observations

The interaction showcased the student's agency in directing their learning process, with the AI adapting its teaching style to match the student's preferences. The tone was supportive yet challenging, encouraging the student to confront errors and refine their understanding. Improvements could include more opportunities for independent exploration and connections to broader mathematical concepts. Overall, the dialogue effectively facilitated the student's conceptual growth within the Pirie-Kieren framework.

---

## 10) Conclusion

This case highlights the importance of adaptive teaching strategies in fostering deep mathematical understanding. The student's journey through the Pirie-Kieren layers, marked by recursive folding-back moments, underscores the value of structured guidance and reflective thinking. The analysis reveals the potential for AI to support personalized learning experiences, with implications for enhancing mathematical cognition through tailored educational interventions.