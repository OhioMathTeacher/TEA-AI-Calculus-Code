# PK-WAP Deep Research Memo — Master Template with Guardrails

---

### Introduction / Context

This analysis pertains to transcript P17-G6-S5, which involves a student engaging with an AI in a mathematical dialogue centered around Taylor polynomial approximations. The scenario requires the student to create a real-world context where Taylor polynomials are necessary, identify a function, and approximate it using a Taylor series. The AI's role is to guide the student through this process using a tailored teaching style based on a preliminary personality test.

---

## 1) Word counts & % student talk by page (estimated)

| Page | Student Words | AI Words | % Student Talk |
| ---: | ------------: | -------: | -------------: |
|    0 |            10 |      150 |              6 |
|    1 |            10 |      100 |              9 |
|    2 |            20 |      150 |             12 |
|    3 |            30 |      150 |             17 |
|    4 |            10 |      150 |              6 |
|    5 |            10 |      150 |              6 |

**Overall student talk:** 90 words (**9**).

---

## 2) Layer Progression Map

```
Primitive Doing → Image-Making → Image-Having → Property-Noticing 
     ↘ (Page 2) ↖
Formalising → Observing → Structuring → Inventising
```

---

## 3) Recursive / folding-back moments (narrative)

A significant folding-back occurs on Page 2 when the student is prompted to choose a specific chaotic system for Taylor polynomial application. Initially, the student provides a broad answer, "various complex problems," which leads the AI to prompt for specificity. This folding-back from Image-Having to Primitive Doing allows the student to refine their understanding by selecting a specific scenario (the drone example) and reconstructing their approach to the problem.

---

## 4) PK layer coding (evidence-rich)

| Layer             | Evidence from transcript | Notes on classification |
| ----------------- | ------------------------ | ----------------------- |
| Primitive Knowing | "exploratory, open-ended" | Initial preferences for learning style. |
| Image-Making      | "Apply the approximation to various complex real problems" | Initial attempt to generalize the task. |
| Image-Having      | "Option one: Because this will cause the computing power of the drone to be overloaded" | Specific scenario selection. |
| Property-Noticing | "When the error is too large" | Recognizing limitations of linear approximations. |
| Formalising       | "a(t) = e^(t^2) sin(mt)" | Identifying the function and its complexity. |
| Observing         | "The real function whispers ~0.4" | Comparing approximation to actual function values. |
| Structuring       | "Use Taylor for t < 0.25" | Developing a strategy for approximation use. |
| Inventising       | "How would you modify the approximation if the drone could measure its own error?" | Considering real-time error correction. |

---

## 5) Page-by-page PK-WAP coding

| Page | Dominant layer(s) | Representative evidence | Notes |
| ---: | ----------------- | ----------------------- | ----- |
|    0 | Primitive Knowing | "exploratory, open-ended" | Establishing learning preferences. |
|    1 | Image-Making      | "Apply the approximation to various complex real problems" | Attempting to generalize the task. |
|    2 | Image-Having      | "Option one: Because this will cause the computing power of the drone to be overloaded" | Specific scenario selection. |
|    3 | Property-Noticing | "When the error is too large" | Recognizing limitations of linear approximations. |
|    4 | Formalising       | "a(t) = e^(t^2) sin(mt)" | Identifying the function and its complexity. |
|    5 | Observing         | "The real function whispers ~0.4" | Comparing approximation to actual function values. |

---

## 6) Representative quotes

**Student:**
1. "exploratory, open-ended" (Page 0) - Indicates preference for learning style.
2. "Apply the approximation to various complex real problems" (Page 1) - Initial broad approach.
3. "Option one: Because this will cause the computing power of the drone to be overloaded" (Page 2) - Specific scenario choice.
4. "When the error is too large" (Page 3) - Recognizing limitations.

**AI:**
1. "Ah, Taylor polynomials. Born from Brook Taylor’s 1715 existential crisis" (Page 2) - Historical context with humor.
2. "Your drone’s accelerometer spits out noisy garbage" (Page 3) - Describing the function's complexity.
3. "You just Taylor-chopped a godzilla into a kitten" (Page 4) - Evaluating the student's approximation.
4. "Reflect: Was Taylor the hero or the villain here?" (Page 5) - Prompting reflection on the process.

---

## 7) Missed opportunities (elaborated)

1. On Page 1, the AI could have explored the student's initial broad approach by asking for examples of "various complex real problems," which might have deepened understanding of the task's scope.
2. On Page 3, the AI could have prompted the student to consider alternative approximation methods earlier, which might have enriched the student's strategic thinking.
3. On Page 4, the AI could have encouraged the student to explore the implications of their approximation in more detail, potentially leading to a deeper understanding of the trade-offs involved.

---

## 8) Summary of Findings

The dialogue demonstrates a dynamic interaction where the student navigates through various Pirie-Kieren layers, primarily moving from Primitive Knowing to Inventising. The AI's use of humor and sarcasm aligns with the student's preferred learning style, fostering engagement and prompting deeper thinking. Key growth moments include the student's ability to specify a real-world scenario and recognize the limitations of their approximation, indicating a progression from Image-Having to Property-Noticing and beyond.

---

## 9) Final observations

The student's journey through the PK layers reveals a developing understanding of Taylor polynomials and their applications. The AI's tailored approach, using wit and challenge, effectively supports the student's conceptual growth. However, opportunities for deeper exploration were occasionally missed, suggesting room for improvement in prompting the student to consider alternative methods and implications more thoroughly.

---

## 10) Conclusion

This case illustrates the importance of aligning teaching styles with student preferences to facilitate recursive understanding. The student's progression through the PK layers, marked by specific folding-back moments, highlights the value of targeted guidance in mathematical cognition. The trajectory from Primitive Knowing to Inventising underscores the potential for AI to support deep learning when pedagogical strategies are effectively employed.