# PK-WAP Deep Research Memo — Master Template with Guardrails

---

### Introduction / Context

This memo analyzes the dialogue transcript P80-G12-S5 using the Pirie-Kieren Work Analysis Protocol (PK-WAP). The scenario involves a student interacting with an AI designed to adapt its teaching style based on the student's responses. The task is to guide the student through understanding Taylor polynomial approximations in a real-world context. The AI's role is to nudge and prompt the student without providing direct answers, fostering a deep exploration of the topic.

---

## 1) Word counts & % student talk by page (estimated)

| Page | Student Words | AI Words | % Student Talk |
| ---: | ------------: | -------: | -------------: |
|    0 |            15 |      285 |              5 |
|    1 |            22 |      158 |             12 |
|    2 |            10 |      190 |              5 |
|    3 |            30 |      170 |             15 |
|    4 |            15 |      185 |              8 |
|    5 |            10 |      190 |              5 |
|    6 |            25 |      175 |             13 |
|    7 |            20 |      180 |             10 |
|    8 |            18 |      182 |              9 |
|    9 |            12 |      188 |              6 |
|   10 |            15 |      185 |              8 |
|   11 |            10 |      190 |              5 |
|   12 |            10 |      190 |              5 |
|   13 |            10 |      190 |              5 |
|   14 |            10 |      190 |              5 |
|   15 |            10 |      190 |              5 |
|   16 |            15 |      185 |              8 |
|   17 |            10 |      190 |              5 |
|   18 |            10 |      190 |              5 |
|   19 |            25 |      175 |             13 |
|   20 |            10 |      190 |              5 |

**Overall student talk:** 322 words (**8%**).

---

## 2) Layer Progression Map

```
Primitive Doing → Image-Making → Image-Having → Property-Noticing
      ↘︎          ↘︎          ↘︎          ↘︎
       ↖︎ Folding-back ↖︎ Folding-back ↖︎ Folding-back
```

---

## 3) Recursive / folding-back moments (narrative)

One significant folding-back moment occurs on Page 3 when the student struggles to articulate why the function \( T(x) = e^{(-x^2)} + \sin(1/x) \) becomes incalculable as \( x \) approaches zero. The AI prompts the student to reconsider the behavior of the function near zero, leading the student to reconstruct their understanding of indeterminate forms and computational limits. This folding-back from Image-Having to Primitive Doing allows the student to solidify their grasp of the function's instability.

Another folding-back moment is observed on Page 9, where the student is guided to reflect on the polynomial's local validity and potential failure points. The AI's nudges encourage the student to revisit their understanding of approximation limits, reinforcing the concept of local vs. global validity.

---

## 4) PK layer coding (evidence-rich)

| Layer             | Evidence from transcript | Notes on classification |
| ----------------- | ------------------------ | ----------------------- |
| Primitive Knowing | Student identifies the function \( T(x) \). | Initial recognition of the problem. |
| Image-Making      | Student draws the chaotic behavior of \( \sin(1/x) \). | Visualizing the function's behavior. |
| Image-Having      | Student describes \( T(x) \) as incalculable near zero. | Conceptual understanding of function limits. |
| Property-Noticing | Student notes the trade-off between precision and practicality. | Recognizing the implications of approximation. |
| Formalising       | Student begins constructing the Taylor polynomial. | Applying mathematical procedures. |
| Observing         | Student reflects on the polynomial's approximation limits. | Evaluating the effectiveness of the approximation. |
| Structuring       | Student articulates the polynomial's local validity. | Synthesizing understanding of approximation. |
| Inventising       | Student considers alternative approximation methods. | Exploring new mathematical strategies. |

---

## 5) Page-by-page PK-WAP coding

| Page | Dominant layer(s) | Representative evidence | Notes |
| ---: | ----------------- | ----------------------- | ----- |
|    0 | Primitive Knowing | Student identifies the task. | Initial engagement with the problem. |
|    1 | Image-Making      | Prefers story-driven approach. | Establishing learning preferences. |
|    2 | Image-Having      | Describes function behavior. | Conceptualizing function instability. |
|    3 | Property-Noticing | Discusses precision trade-offs. | Recognizing practical implications. |
|    4 | Formalising       | Begins Taylor polynomial. | Applying mathematical concepts. |
|    5 | Observing         | Reflects on polynomial limits. | Evaluating approximation effectiveness. |
|    6 | Structuring       | Articulates local validity. | Synthesizing understanding. |
|    7 | Inventising       | Considers alternative methods. | Exploring new strategies. |

---

## 6) Representative quotes

**Student:**
1. "As \( x \) approaches 0, \( \frac{1}{x} \) will tend towards infinity, making \( \sin\left(\frac{1}{x}\right) \) indeterminate." (Page 2)
2. "In image and video compression, to reduce file size, some image quality is sacrificed." (Page 3)
3. "Use constant term, trying to fix \( T(x) \) at \( T(0.5) \), and dx." (Page 9)
4. "Before today, I thought Taylor series were just a formula to deal with difficult numbers or functions." (Page 19)

**AI:**
1. "Imagine a teacher correcting you mid-lesson. Would you rather they: (a) tease you lightly to defuse tension, (b) calmly point out the gap in your logic, or (c) reframe the mistake as a ‘detour’ we'll fix together?" (Page 1)
2. "Ah! So at \( x=0 \), your sensor's temperature function throws a tantrum — like a GPS screaming ‘RECALCULATING’ forever." (Page 2)
3. "You've just described the soul of applied math: trading a ‘perfect’ answer for one that’s useful." (Page 3)
4. "Want to test your newfound ‘good enough’ intuition? Try this: Approximate \( \frac{1}{1-x} \) using a Taylor series for \( a=1 \)." (Page 20)

---

## 7) Missed opportunities (elaborated)

1. **Page 2:** The AI could have provided a more explicit connection between the student's description of \( \sin(1/x) \) and the concept of limits, which might have deepened the student's understanding of indeterminate forms.
   
2. **Page 4:** When discussing the trade-off between precision and practicality, the AI missed an opportunity to introduce real-world examples of approximation in engineering, which could have contextualized the mathematical concepts further.

3. **Page 9:** The AI could have encouraged the student to explore the implications of polynomial degree on approximation accuracy, potentially leading to a richer understanding of error analysis.

---

## 8) Summary of Findings

The dialogue between the student and AI demonstrates a dynamic interaction where the student is guided through various layers of understanding within the Pirie-Kieren framework. The student begins with a basic recognition of the problem and progresses through visualizing and conceptualizing the function's behavior. The AI effectively uses prompts and nudges to facilitate the student's movement through the layers, encouraging reflection and synthesis of ideas. The tone is supportive yet challenging, fostering an environment where the student feels comfortable exploring complex concepts.

---

## 9) Final observations

The student's journey through the PK layers highlights significant growth in understanding Taylor polynomial approximations. The AI's adaptive teaching style, informed by the student's preferences, plays a crucial role in maintaining engagement and promoting deeper learning. However, there are missed opportunities where the AI could have further enriched the student's conceptual framework by introducing additional real-world applications and encouraging exploration of error analysis. Overall, the dialogue exemplifies the potential of AI to support recursive understanding in mathematical learning.

---

## 10) Conclusion

This case illustrates the effectiveness of AI in facilitating recursive understanding through the Pirie-Kieren framework. The student's trajectory from Primitive Knowing to Inventising demonstrates significant conceptual growth, underscored by the AI's strategic use of prompts and nudges. The dialogue underscores the importance of adaptive teaching methods in promoting deep mathematical cognition, with implications for future AI-driven educational tools.