# PK-WAP Deep Research Memo — Master Template with Guardrails

---

### Introduction / Context

This memo analyzes transcript P77-G8-S5 using the Pirie-Kieren Work Analysis Protocol (PK-WAP). The dialogue involves a student interacting with an AI to explore Taylor polynomial approximations in a real-world context. The AI adopts a humorous and supportive teaching persona, guiding the student through a structured activity designed to last 40 minutes. Unlabeled student turns that answer AI prompts are treated as student turns.

---

## 1) Word counts & % student talk by page (estimated)

| Page | Student Words | AI Words | % Student Talk |
| ---: | ------------: | -------: | -------------: |
|    0 |             0 |      250 |              0 |
|    1 |            20 |      230 |              8 |
|    2 |           100 |      180 |             36 |
|    3 |           150 |      150 |             50 |
|    4 |           120 |      180 |             40 |
|    5 |           100 |      200 |             33 |
|    6 |           130 |      170 |             43 |
|    7 |           110 |      190 |             37 |
|    8 |            10 |      240 |              4 |

**Overall student talk:** 740 words (**31**).

---

## 2) Layer Progression Map

```
Primitive Doing → Image-Making → Image-Having → Property-Noticing
   ↘︎ (Page 2)  ↘︎ (Page 3)     ↘︎ (Page 4)     ↘︎ (Page 5)
Formalising → Observing → Structuring → Inventising
   ↘︎ (Page 5)  ↘︎ (Page 6)   ↘︎ (Page 7)   ↘︎ (Page 8)
```

---

## 3) Recursive / folding-back moments (narrative)

The first significant folding-back occurs on Page 2, where the student revisits the complexity of modeling a frisbee's trajectory under changing wind conditions. Initially, the student struggles with Primitive Doing, attempting to describe the problem. The AI's humorous prompts help the student fold back to Image-Making, where they articulate the chaotic nature of the problem more clearly.

Another folding-back moment is observed on Page 5, as the student attempts to construct a Taylor polynomial. Initially, they engage in Property-Noticing, identifying the polynomial's components. However, the AI's guidance prompts a fold-back to Image-Having, allowing the student to refine their understanding of the polynomial's structure and its application to the problem.

---

## 4) PK layer coding (evidence-rich)

| Layer             | Evidence from transcript | Notes on classification |
| ----------------- | ------------------------ | ----------------------- |
| Primitive Knowing | Student identifies frisbee problem | Initial recognition of problem context |
| Image-Making      | Describes wind's impact on trajectory | Developing a mental model of the problem |
| Image-Having      | Articulates complexity of x(t) function | Clearer understanding of problem elements |
| Property-Noticing | Identifies polynomial components | Recognizing specific mathematical properties |
| Formalising       | Constructs Taylor polynomial | Applying formal mathematical processes |
| Observing         | Evaluates polynomial accuracy | Reflecting on the approximation's validity |
| Structuring       | Suggests piecewise approximation | Organizing knowledge into a coherent strategy |
| Inventising       | Proposes adaptive method | Creating new approaches to problem-solving |

---

## 5) Page-by-page PK-WAP coding

| Page | Dominant layer(s) | Representative evidence | Notes |
| ---: | ----------------- | ----------------------- | ----- |
|    0 | Primitive Knowing | AI introduces task | Context setting |
|    1 | Image-Making      | Student describes learning preferences | Establishing learning style |
|    2 | Image-Having      | Student articulates frisbee problem | Deepening understanding |
|    3 | Property-Noticing | Identifies forces affecting trajectory | Recognizing problem properties |
|    4 | Formalising       | Constructs Taylor polynomial | Applying mathematical concepts |
|    5 | Observing         | Evaluates polynomial's limitations | Reflecting on solution accuracy |
|    6 | Structuring       | Suggests piecewise approach | Organizing solution strategy |
|    7 | Inventising       | Proposes adaptive method | Innovating new solutions |
|    8 | Observing         | Reflects on learning process | Synthesizing experience |

---

## 6) Representative quotes

**Student:**
1. "I was thinking about calculating the exact trajectory of a tossed frisbee on a windy day." (Page 2) - Demonstrates initial problem identification.
2. "The function for x(t) is disgustingly complex." (Page 3) - Highlights understanding of problem complexity.
3. "For the simplest x(t) near t = 0, assume the wind speed is constant." (Page 4) - Shows application of simplification strategies.
4. "Errors will pile up fast! Using past endpoints as new starts makes tiny errors snowball." (Page 7) - Reflects on limitations of proposed solution.

**AI:**
1. "Ohhh, a frisbee in the wind? That’s not just a headache—that’s calculus on hard mode." (Page 2) - Uses humor to engage student.
2. "Let's turn this hot mess into a Taylor polynomial’s finest hour." (Page 3) - Encourages student to apply mathematical concepts.
3. "Taylor polynomials are the ultimate ‘fake it till you make it’ math." (Page 4) - Provides conceptual insight.
4. "You've just reinvented a billion-dollar technique." (Page 6) - Validates student's innovative approach.

---

## 7) Missed opportunities (elaborated)

1. On Page 3, the AI could have prompted the student to explore alternative modeling approaches before settling on Taylor polynomials, deepening their understanding of problem-solving strategies.
2. On Page 5, the AI missed an opportunity to discuss the historical development of Taylor series, which could have enriched the student's appreciation of the method's significance.
3. On Page 6, the AI could have encouraged the student to simulate the piecewise approximation using software, providing a practical application of their theoretical understanding.

---

## 8) Summary of Findings

The dialogue demonstrates significant engagement, with the student actively participating in problem-solving and conceptual exploration. The progression through the Pirie-Kieren layers indicates a deepening understanding of Taylor polynomials, from initial recognition to innovative application. The AI's humorous and supportive tone effectively maintains student motivation and encourages exploration. Key growth moments include the student's realization of the polynomial's limitations and their proposal of a piecewise approximation method.

---

## 9) Final observations

The student's journey through the PK layers highlights their growing agency in mathematical problem-solving. The AI's adaptive teaching style, characterized by humor and encouragement, fosters a positive learning environment. Future interactions could benefit from more explicit connections to historical and practical contexts, enhancing the student's conceptual framework and appreciation for mathematical methods.

---

## 10) Conclusion

This case illustrates the dynamic interplay between student and AI in exploring complex mathematical concepts. The student's trajectory through the PK layers, culminating in innovative problem-solving, underscores the potential of AI-facilitated learning environments. The dialogue exemplifies how humor and support can enhance engagement and conceptual growth, offering valuable insights for educational practice.