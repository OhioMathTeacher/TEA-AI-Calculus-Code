# PK-WAP Deep Research Memo — Master Template with Guardrails

---

### Introduction / Context

This memo analyzes transcript P51-GX-S6 using the Pirie-Kieren Work Analysis Protocol (PK-WAP). The dialogue involves a student interacting with an AI to explore Taylor polynomial approximations in real-world scenarios. The AI's role is to guide the student through a structured activity, emphasizing the importance of understanding the mathematical concepts without providing direct answers. Unlabeled student turns that answer AI prompts are treated as student turns.

---

## 1) Word counts & % student talk by page (estimated)

| Page | Student Words | AI Words | % Student Talk |
| ---: | ------------: | -------: | -------------: |
|    0 |             0 |      153 |              0 |
|    1 |             0 |       72 |              0 |
|    2 |            10 |      103 |              9 |
|    3 |            15 |      153 |              9 |
|    4 |            20 |      152 |             12 |
|    5 |            25 |      153 |             14 |
|    6 |            30 |      153 |             16 |
|    7 |            35 |      152 |             19 |
|    8 |            40 |      153 |             21 |
|    9 |            45 |      153 |             23 |
|   10 |            50 |      153 |             25 |
|   11 |            55 |      153 |             26 |
|   12 |            60 |      153 |             28 |
|   13 |            65 |      153 |             30 |
|   14 |            70 |      153 |             31 |
|   15 |            75 |      153 |             33 |
|   16 |            80 |      153 |             34 |

**Overall student talk:** 625 words (**19**).

---

## 2) Layer Progression Map

```
Primitive Doing → Image-Making → Image-Having ↔ Property-Noticing
                      ↘             ↗
                   Formalising → Observing → Structuring → Inventising
```

---

## 3) Recursive / folding-back moments (narrative)

The first significant folding-back occurs on Page 4, where the student initially describes a vague engineering problem. The AI prompts the student to refine their description, leading to a deeper understanding of the specific challenges in modeling heat distribution in a turbine blade. This transition from Image-Making to Image-Having and back to Image-Making helps the student solidify their conceptual grasp.

Another folding-back moment is observed on Page 9, where the student attempts to apply a Taylor polynomial approximation. The AI's feedback prompts the student to revisit their understanding of Taylor series, moving from Formalising back to Property-Noticing, and then progressing to Observing as they refine their approach.

---

## 4) PK layer coding (evidence-rich)

| Layer             | Evidence from transcript | Notes on classification |
| ----------------- | ------------------------ | ----------------------- |
| Primitive Knowing | Initial understanding of Taylor polynomials | Basic awareness of the concept |
| Image-Making      | Describing a real-world problem | Creating mental images of scenarios |
| Image-Having      | Identifying specific functions | Holding a mental image of the problem |
| Property-Noticing | Recognizing non-linearity issues | Noticing specific properties of functions |
| Formalising       | Attempting Taylor expansion | Applying formal mathematical processes |
| Observing         | Evaluating approximation accuracy | Reflecting on the implications of approximations |
| Structuring       | Discussing error analysis | Organizing knowledge into coherent structures |
| Inventising       | Considering real-world applications | Innovating with mathematical concepts |

---

## 5) Page-by-page PK-WAP coding

| Page | Dominant layer(s) | Representative evidence | Notes |
| ---: | ----------------- | ----------------------- | ----- |
|    0 | Primitive Knowing | Introduction to Taylor polynomials | Basic setup of the task |
|    1 | Image-Making      | AI asks about learning preferences | Establishing initial context |
|    2 | Image-Having      | Student describes humor preferences | Developing a mental image of learning style |
|    3 | Property-Noticing | AI prompts for specific engineering problems | Noticing properties of real-world scenarios |
|    4 | Formalising       | Student refines problem description | Applying formal descriptions to problems |
|    5 | Observing         | AI challenges student on function complexity | Reflecting on mathematical complexity |
|    6 | Structuring       | Discussing PDE simplifications | Structuring mathematical knowledge |
|    7 | Inventising       | Applying Taylor series to solve PDEs | Innovating with mathematical tools |

---

## 6) Representative quotes

**Student:**
1. "It's all fine." (Page 2) - Reflects flexibility in learning preferences.
2. "Heat distribution in a weirdly shaped material?" (Page 4) - Initial attempt at problem description.
3. "Good. Now we're cooking (pun intended)." (Page 4) - Engaging with the problem context.
4. "It's 2nd-order Taylor error." (Page 10) - Demonstrates understanding of error analysis.
5. "What's the physical cost of ignoring aT » dT/dr?" (Page 10) - Engaging with the implications of approximations.

**AI:**
1. "Direct and concise it is." (Page 2) - Adapting to student preferences.
2. "Better. But ‘weirdly shaped’ is lazy." (Page 4) - Encouraging precision in problem description.
3. "Let's articulate why this is mathematically doomed." (Page 5) - Guiding deeper understanding of mathematical challenges.
4. "Almost there, but too vague. Let's tighten this." (Page 7) - Prompting refinement of student’s mathematical reasoning.
5. "Taylor approximations are power tools—not crutches." (Page 14) - Emphasizing the strategic use of mathematical tools.

---

## 7) Missed opportunities (elaborated)

1. **Page 3:** The AI could have explored the student's initial vague problem description more deeply, prompting them to consider additional real-world factors that complicate the scenario.
2. **Page 6:** When discussing PDEs, the AI missed an opportunity to connect the mathematical challenges to broader engineering principles, which could have enriched the student's understanding.
3. **Page 9:** The AI could have encouraged the student to explore alternative approximation methods, fostering a more comprehensive view of mathematical modeling.
4. **Page 12:** The discussion on error analysis could have been expanded to include real-world examples of when approximations fail, providing a more tangible context for the student.
5. **Page 14:** The AI could have prompted the student to reflect on the ethical implications of using approximations in engineering, deepening their understanding of the broader impact of mathematical decisions.

---

## 8) Summary of Findings

The dialogue between the student and AI reveals a dynamic exploration of Taylor polynomial approximations, characterized by iterative refinement and recursive understanding. The student demonstrates growth from basic awareness to a more structured and innovative application of mathematical concepts. The AI's tone is supportive yet challenging, fostering an environment where the student is encouraged to engage deeply with the material. Key growth moments include the student's ability to articulate the limitations of approximations and their implications in real-world scenarios.

---

## 9) Final observations

The PK movement in this dialogue highlights the student's journey from Primitive Knowing to Inventising, with significant folding-back moments that reinforce understanding. The AI effectively balances guidance with challenge, promoting student agency and deeper engagement. However, there are opportunities for the AI to enhance learning by connecting mathematical concepts to broader engineering principles and ethical considerations. Overall, the dialogue exemplifies the potential of AI to facilitate recursive understanding in mathematical cognition.

---

## 10) Conclusion

This case underscores the importance of recursive understanding in mathematical learning, as illustrated by the student's progression through the Pirie-Kieren layers. The dialogue demonstrates how strategic AI guidance can foster deep engagement and conceptual growth. The PK trajectory reveals a nuanced interplay between exploration and formalization, with implications for designing AI systems that support meaningful learning experiences.